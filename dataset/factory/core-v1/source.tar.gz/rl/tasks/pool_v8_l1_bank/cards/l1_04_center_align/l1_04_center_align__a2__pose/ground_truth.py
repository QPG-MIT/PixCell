import json
from pathlib import Path

import gdsfactory as gf

layer = (1, 0)
ring_radius_um = 17.0
ring_width_um = 3.5
cross_length_um = 14.0
cross_width_um = 4.0
center_x_um = -2.0
center_y_um = 3.0
pose_rotation_deg = 45.0


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    pose_scene = gf.Component()
    ring = pose_scene << gf.components.ring(
        radius=ring_radius_um, width=ring_width_um, layer=layer
    )
    cross = pose_scene << gf.components.cross(
        length=cross_length_um, width=cross_width_um, layer=layer
    )
    ring.move((center_x_um, center_y_um))
    cross.move((center_x_um, center_y_um))
    pose_ref = c << pose_scene
    pose_ref.rotate(pose_rotation_deg)
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
