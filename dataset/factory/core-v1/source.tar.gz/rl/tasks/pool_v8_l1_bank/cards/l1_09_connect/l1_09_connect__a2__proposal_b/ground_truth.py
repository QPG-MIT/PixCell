import json
from pathlib import Path

import gdsfactory as gf

layer = (1, 0)
width_um = 4.56
default_bend_radius_um = 11.4
minimum_bend_radius_um = 2.28
lead_length_um = 23.94
offset_x_um = 36.48
offset_y_um = 18.24
tail_length_um = 27.36


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    xs = gf.cross_section.cross_section(
        width=width_um,
        layer=layer,
        radius=default_bend_radius_um,
        radius_min=minimum_bend_radius_um,
    )
    lead = c << gf.components.straight(
        length=lead_length_um, cross_section=xs
    )
    middle = c << gf.components.bend_s(
        size=(offset_x_um, offset_y_um), cross_section=xs
    )
    ref = c << gf.components.straight(
        length=tail_length_um, cross_section=xs
    )
    middle.connect("o1", lead.ports["o2"])
    ref.connect("o1", middle.ports["o2"])
    c.add_port("o1", port=lead.ports["o1"])
    c.add_port("o2", port=ref.ports["o2"])

    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
