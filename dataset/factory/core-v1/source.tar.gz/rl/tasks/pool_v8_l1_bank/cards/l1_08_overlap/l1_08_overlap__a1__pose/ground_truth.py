import json
from pathlib import Path

import gdsfactory as gf

layer = (1, 0)
ellipse_radius_x_um = 16.0
ellipse_radius_y_um = 10.0
disk_radius_um = 9.0
offset_x_um = 13.0
offset_y_um = 3.0
pose_rotation_deg = 90.0


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    pose_scene = gf.Component()
    ellipse = pose_scene << gf.components.ellipse(
        radii=(ellipse_radius_x_um, ellipse_radius_y_um), layer=layer
    )
    disk = pose_scene << gf.components.circle(radius=disk_radius_um, layer=layer)
    disk.move((offset_x_um, offset_y_um))
    pose_ref = c << pose_scene
    pose_ref.rotate(pose_rotation_deg)
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
