import json
from pathlib import Path

import gdsfactory as gf

dx_um = 82.08
dy_um = -38.76
end_rotation_deg = 180.0
radius_um = 7.98
layer = (1, 0)


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    xs = gf.cross_section.cross_section(
        width=4.0, layer=layer, radius=radius_um, radius_min=2.0
    )
    start = c << gf.components.straight(length=12.0, cross_section=xs)
    end = c << gf.components.straight(length=12.0, cross_section=xs)
    end.rotate(end_rotation_deg)
    end.move((dx_um, dy_um))
    gf.routing.route_single(
        c, start.ports["o2"], end.ports["o2"],
        cross_section=xs, radius=radius_um,

    )
    c.add_port("o1", port=start.ports["o1"])
    c.add_port("o2", port=end.ports["o1"])
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
