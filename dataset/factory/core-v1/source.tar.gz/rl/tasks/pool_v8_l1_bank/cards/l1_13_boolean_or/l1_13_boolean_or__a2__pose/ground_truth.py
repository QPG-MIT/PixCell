import json
from pathlib import Path

import gdsfactory as gf

lobe_offset_um = 14.0
bridge_width_um = 6.0
layer = (1, 0)
pose_rotation_deg = 45.0


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    pose_scene = gf.Component()
    lobes = gf.Component()
    left = lobes << gf.components.circle(radius=12.0, layer=layer)
    right = lobes << gf.components.circle(radius=12.0, layer=layer)
    left.move((-lobe_offset_um, 0))
    right.move((lobe_offset_um, 0))
    bridge = gf.components.rectangle(
        size=(2 * lobe_offset_um, bridge_width_um),
        layer=layer, centered=True
    )
    result = pose_scene << gf.boolean(
        A=lobes, B=bridge, operation="or", layer=layer
    )
    pose_ref = c << pose_scene
    pose_ref.rotate(pose_rotation_deg)
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
