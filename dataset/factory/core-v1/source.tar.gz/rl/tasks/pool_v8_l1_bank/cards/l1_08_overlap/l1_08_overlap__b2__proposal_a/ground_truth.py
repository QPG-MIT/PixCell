import json
from pathlib import Path

import gdsfactory as gf

layer = (1, 0)
arm_width_um = 6.0
size_x_um = 30.0
size_y_um = 30.0
disk_radius_um = 10.0
offset_x_um = 9.0
offset_y_um = 9.0


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    elbow = c << gf.components.L(
        width=arm_width_um, size=(size_x_um, size_y_um), layer=layer
    )
    disk = c << gf.components.circle(radius=disk_radius_um, layer=layer)
    disk.move((offset_x_um, offset_y_um))

    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
