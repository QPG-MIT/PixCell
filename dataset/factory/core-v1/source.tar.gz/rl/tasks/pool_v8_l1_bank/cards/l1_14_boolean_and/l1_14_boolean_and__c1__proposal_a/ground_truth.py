import json
from pathlib import Path

import gdsfactory as gf

bar_width_um = 10.0
layer = (1, 0)


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    ring = gf.components.ring(radius=15.0, width=4.0, layer=layer)
    bar = gf.components.rectangle(
        size=(bar_width_um, 38.0), layer=layer, centered=True
    )
    result = c << gf.boolean(
        A=ring, B=bar, operation="and", layer=layer
    )
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
