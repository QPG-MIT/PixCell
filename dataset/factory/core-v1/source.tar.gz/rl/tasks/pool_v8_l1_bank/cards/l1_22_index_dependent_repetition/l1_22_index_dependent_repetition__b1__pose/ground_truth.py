import json
from pathlib import Path

import gdsfactory as gf

count = 7
pitch_um = 13.0
layer = (1, 0)
pose_rotation_deg = 135.0


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    pose_scene = gf.Component()
    for index in range(count):
        distance = abs(index - (count - 1) / 2)
        radius_um = 7.0 - 1.0 * distance
        item = pose_scene << gf.components.circle(radius=radius_um, layer=layer)
        item.move((index * pitch_um, 0))
    pose_ref = c << pose_scene
    pose_ref.rotate(pose_rotation_deg)
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
