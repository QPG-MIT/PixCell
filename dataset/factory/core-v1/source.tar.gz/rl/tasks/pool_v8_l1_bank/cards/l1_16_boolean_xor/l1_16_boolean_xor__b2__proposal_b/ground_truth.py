import json
from pathlib import Path

import gdsfactory as gf

circle_dx_um = 14.82
circle_dy_um = 5.7
layer = (1, 0)


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    triangle = gf.components.triangle(x=34.0, y=29.0, layer=layer)
    disk_parent = gf.Component()
    disk = disk_parent << gf.components.circle(radius=13.0, layer=layer)
    disk.move((circle_dx_um, circle_dy_um))
    result = c << gf.boolean(
        A=triangle, B=disk_parent, operation="xor", layer=layer
    )
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
