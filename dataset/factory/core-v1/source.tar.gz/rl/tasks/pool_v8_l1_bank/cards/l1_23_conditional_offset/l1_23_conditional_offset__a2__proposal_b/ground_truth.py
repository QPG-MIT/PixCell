import json
from pathlib import Path

import gdsfactory as gf

count = 9
pitch_um = 12.54
offset_um = 9.12
layer = (1, 0)


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    for index in range(count):
        lane = index % 3
        y_um = (lane - 1) * offset_um
        item = c << gf.components.circle(radius=3.6, layer=layer)
        item.move((index * pitch_um, y_um))
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
