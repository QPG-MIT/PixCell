import json
from pathlib import Path

import gdsfactory as gf

layer = (1, 0)
arm_width_um = 5.13
size_x_um = 17.1
size_y_um = 23.94
angle_step_deg = 48.0
orbit_um = 26.22


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    import math
    for index in range(3):
        angle_deg = (index - 1) * angle_step_deg
        angle_rad = math.radians(angle_deg)
        ref = c << gf.components.L(
            width=arm_width_um,
            size=(size_x_um, size_y_um),
            layer=layer,
        )
        ref.rotate(angle_deg)
        ref.move((
            orbit_um * math.cos(angle_rad),
            orbit_um * math.sin(angle_rad),
        ))

    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
