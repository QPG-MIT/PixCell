import json
from pathlib import Path

import gdsfactory as gf

offset_x_um = 8.0
offset_y_um = 4.0
layer = (1, 0)
pose_rotation_deg = 135.0


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    pose_scene = gf.Component()
    elbow = gf.components.L(
        width=7.0, size=(28.0, 31.0), layer=layer
    )
    ellipse_parent = gf.Component()
    ellipse = ellipse_parent << gf.components.ellipse(
        radii=(14.0, 9.0), layer=layer
    )
    ellipse.move((offset_x_um, offset_y_um))
    result = pose_scene << gf.boolean(
        A=elbow, B=ellipse_parent, operation="or", layer=layer
    )
    pose_ref = c << pose_scene
    pose_ref.rotate(pose_rotation_deg)
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
