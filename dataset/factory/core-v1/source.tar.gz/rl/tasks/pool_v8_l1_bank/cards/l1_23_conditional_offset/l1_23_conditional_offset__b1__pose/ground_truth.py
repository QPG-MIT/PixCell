import json
from pathlib import Path

import gdsfactory as gf

count = 8
pitch_um = 11.0
offset_um = 8.0
layer = (1, 0)
pose_rotation_deg = 135.0


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    pose_scene = gf.Component()
    for index in range(count):
        y_um = -offset_um if index < count / 2 else offset_um
        item = pose_scene << gf.components.rectangle(
            size=(5.0, 12.0), layer=layer, centered=True
        )
        item.move((index * pitch_um, y_um))
    pose_ref = c << pose_scene
    pose_ref.rotate(pose_rotation_deg)
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
