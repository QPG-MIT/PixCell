import json
from pathlib import Path

import gdsfactory as gf

layer = (1, 0)
disk_radius_um = 6.27
cross_length_um = 14.82
cross_width_um = 4.56
pair_separation_y_um = 25.08
translation_x_um = 36.48


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    disk_original = c << gf.components.circle(
        radius=disk_radius_um, layer=layer
    )
    disk_original.move((-translation_x_um / 2, -pair_separation_y_um / 2))
    disk_ref = c << gf.components.circle(
        radius=disk_radius_um, layer=layer
    )
    disk_ref.move((translation_x_um / 2, -pair_separation_y_um / 2))
    cross_original = c << gf.components.cross(
        length=cross_length_um, width=cross_width_um, layer=layer
    )
    cross_original.move((-translation_x_um / 2, pair_separation_y_um / 2))
    ref = c << gf.components.cross(
        length=cross_length_um, width=cross_width_um, layer=layer
    )
    ref.move((translation_x_um / 2, pair_separation_y_um / 2))

    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
