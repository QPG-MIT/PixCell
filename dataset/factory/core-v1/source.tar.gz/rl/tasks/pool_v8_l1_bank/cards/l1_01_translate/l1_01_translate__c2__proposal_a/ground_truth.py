import json
from pathlib import Path

import gdsfactory as gf

layer = (1, 0)
block_length_um = 25.0
block_width_um = 7.0
disk_radius_um = 4.5
disk_offset_x_um = 9.0
disk_offset_y_um = 8.0
translation_x_um = 43.0
translation_y_um = -15.0


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    unit = gf.Component()
    block = unit << gf.components.rectangle(
        size=(block_length_um, block_width_um),
        layer=layer,
        centered=True,
    )
    disk = unit << gf.components.circle(radius=disk_radius_um, layer=layer)
    disk.move((disk_offset_x_um, disk_offset_y_um))
    original = c << unit
    original.move((-translation_x_um / 2, -translation_y_um / 2))
    ref = c << unit
    ref.move((translation_x_um / 2, translation_y_um / 2))

    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
