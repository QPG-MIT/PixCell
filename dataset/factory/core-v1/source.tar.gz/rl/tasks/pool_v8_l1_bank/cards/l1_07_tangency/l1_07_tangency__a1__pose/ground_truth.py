import json
from pathlib import Path

import gdsfactory as gf

layer = (1, 0)
left_radius_um = 12.0
right_radius_um = 8.0
pose_rotation_deg = 90.0


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    pose_scene = gf.Component()
    left = pose_scene << gf.components.circle(radius=left_radius_um, layer=layer)
    right = pose_scene << gf.components.circle(radius=right_radius_um, layer=layer)
    right.move((left_radius_um + right_radius_um, 0))
    pose_ref = c << pose_scene
    pose_ref.rotate(pose_rotation_deg)
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
