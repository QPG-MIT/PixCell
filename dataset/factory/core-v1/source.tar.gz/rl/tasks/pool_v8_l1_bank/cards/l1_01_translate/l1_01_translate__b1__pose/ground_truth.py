import json
from pathlib import Path

import gdsfactory as gf

layer = (1, 0)
radius_x_um = 9.0
radius_y_um = 5.0
step_x_um = 25.0
step_y_um = 12.0
pose_rotation_deg = 135.0


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    pose_scene = gf.Component()
    for index in range(3):
        ref = pose_scene << gf.components.ellipse(
            radii=(radius_x_um, radius_y_um), layer=layer
        )
        ref.move((
            (index - 1) * step_x_um,
            (index - 1) * step_y_um,
        ))
    pose_ref = c << pose_scene
    pose_ref.rotate(pose_rotation_deg)
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
