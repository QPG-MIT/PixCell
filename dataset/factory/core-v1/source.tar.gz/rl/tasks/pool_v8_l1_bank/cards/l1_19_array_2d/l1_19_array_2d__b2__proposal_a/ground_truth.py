import json
from pathlib import Path

import gdsfactory as gf

rows = 3
columns = 4
pitch_x_um = 14.0
pitch_y_um = 16.0
layer = (1, 0)


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    unit = gf.components.rectangle(
        size=(5.0, 9.0), layer=layer, centered=True
    )
    ref = c.add_ref(
        unit, columns=columns, rows=rows,
        column_pitch=pitch_x_um, row_pitch=pitch_y_um
    )
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
