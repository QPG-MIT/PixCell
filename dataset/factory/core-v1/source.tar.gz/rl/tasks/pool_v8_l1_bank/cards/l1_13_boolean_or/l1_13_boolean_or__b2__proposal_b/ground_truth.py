import json
from pathlib import Path

import gdsfactory as gf

bar_dx_um = 7.98
layer = (1, 0)


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    ring = gf.components.ring(radius=15.0, width=4.5, layer=layer)
    bar_parent = gf.Component()
    bar = bar_parent << gf.components.rectangle(
        size=(12.0, 38.0), layer=layer, centered=True
    )
    bar.move((bar_dx_um, 0))
    result = c << gf.boolean(
        A=ring, B=bar_parent, operation="or", layer=layer
    )
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
