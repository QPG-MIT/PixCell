import json
from pathlib import Path

import gdsfactory as gf

layer = (1, 0)
ellipse_radius_x_um = 16.0
ellipse_radius_y_um = 10.0
disk_radius_um = 9.0
offset_x_um = 13.0
offset_y_um = 3.0


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    ellipse = c << gf.components.ellipse(
        radii=(ellipse_radius_x_um, ellipse_radius_y_um), layer=layer
    )
    disk = c << gf.components.circle(radius=disk_radius_um, layer=layer)
    disk.move((offset_x_um, offset_y_um))

    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
