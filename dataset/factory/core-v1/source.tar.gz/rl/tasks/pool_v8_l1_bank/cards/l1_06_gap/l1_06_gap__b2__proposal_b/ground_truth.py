import json
from pathlib import Path

import gdsfactory as gf

layer = (1, 0)
outer_radius_um = 20.52
outer_width_um = 3.42
inner_radius_um = 11.4
inner_width_um = 3.42


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    outer = c << gf.components.ring(
        radius=outer_radius_um, width=outer_width_um, layer=layer
    )
    inner = c << gf.components.ring(
        radius=inner_radius_um, width=inner_width_um, layer=layer
    )

    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
