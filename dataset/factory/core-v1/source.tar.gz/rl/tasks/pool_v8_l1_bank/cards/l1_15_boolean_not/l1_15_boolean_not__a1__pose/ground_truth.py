import json
from pathlib import Path

import gdsfactory as gf

wall_um = 5.0
layer = (1, 0)
pose_rotation_deg = 90.0


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    pose_scene = gf.Component()
    outer = gf.components.rectangle(
        size=(38.0, 27.0), layer=layer, centered=True
    )
    inner = gf.components.rectangle(
        size=(38.0 - 2 * wall_um, 27.0 - 2 * wall_um),
        layer=layer, centered=True
    )
    result = pose_scene << gf.boolean(
        A=outer, B=inner, operation="not", layer=layer
    )
    pose_ref = c << pose_scene
    pose_ref.rotate(pose_rotation_deg)
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
