import json
from pathlib import Path

import gdsfactory as gf

layer = (1, 0)
block_length_um = 23.0
block_width_um = 7.0
disk_radius_um = 5.0
disk_offset_x_um = 7.0
disk_offset_y_um = 8.0
angle_deg = 58.0
separation_x_um = 46.0


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    unit = gf.Component()
    block = unit << gf.components.rectangle(
        size=(block_length_um, block_width_um),
        layer=layer,
        centered=True,
    )
    disk = unit << gf.components.circle(radius=disk_radius_um, layer=layer)
    disk.move((disk_offset_x_um, disk_offset_y_um))
    original = c << unit
    original.move((-separation_x_um / 2, 0))
    ref = c << unit
    ref.rotate(angle_deg)
    ref.move((separation_x_um / 2, 0))

    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
