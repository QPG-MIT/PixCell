import json
from pathlib import Path

import gdsfactory as gf

narrow1_um = 4.56
wide_um = 13.68
narrow2_um = 6.84
layer = (1, 0)


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    xs1 = gf.cross_section.cross_section(
        width=narrow1_um, layer=layer, radius=8.0, radius_min=1.0
    )
    xs2 = gf.cross_section.cross_section(
        width=wide_um, layer=layer, radius=8.0, radius_min=1.0
    )
    xs3 = gf.cross_section.cross_section(
        width=narrow2_um, layer=layer, radius=8.0, radius_min=1.0
    )
    first = c << gf.components.straight(length=22.0, cross_section=xs1)
    middle = c << gf.components.straight(length=25.0, cross_section=xs2)
    last = c << gf.components.straight(length=23.0, cross_section=xs3)
    middle.connect("o1", first.ports["o2"], allow_width_mismatch=True)
    last.connect("o1", middle.ports["o2"], allow_width_mismatch=True)
    c.add_port("o1", port=first.ports["o1"])
    c.add_port("o2", port=last.ports["o2"])
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
