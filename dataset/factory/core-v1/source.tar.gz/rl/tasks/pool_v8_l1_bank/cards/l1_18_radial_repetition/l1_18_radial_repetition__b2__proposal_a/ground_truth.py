import json
from pathlib import Path

import gdsfactory as gf

count = 7
orbit_um = 25.0
span_deg = 210.0
layer = (1, 0)


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    import math
    for index in range(count):
        angle_deg = -105.0 + index * span_deg / (count - 1)
        angle_rad = math.radians(angle_deg)
        item = c << gf.components.rectangle(
            size=(5.0, 14.0), layer=layer, centered=True
        )
        item.rotate(angle_deg)
        item.move((
            orbit_um * math.cos(angle_rad),
            orbit_um * math.sin(angle_rad),
        ))
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
