import json
from pathlib import Path

import gdsfactory as gf

rows = 3
columns = 4
pitch_x_um = 19.38
pitch_y_um = 15.96
layer = (1, 0)


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    for row in range(rows):
        for column in range(columns):
            item = c << gf.components.circle(radius=3.7, layer=layer)
            item.move((
                column * pitch_x_um,
                row * pitch_y_um,
            ))
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
