import json
from pathlib import Path

import gdsfactory as gf

left_dx_um = -11.4
right_dx_um = 9.12
right_dy_um = 4.56
layer = (1, 0)


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    outer = gf.components.ellipse(radii=(26.0, 17.0), layer=layer)
    cutters = gf.Component()
    left = cutters << gf.components.circle(radius=6.5, layer=layer)
    right = cutters << gf.components.circle(radius=4.5, layer=layer)
    left.move((left_dx_um, 0))
    right.move((right_dx_um, right_dy_um))
    result = c << gf.boolean(
        A=outer, B=cutters, operation="not", layer=layer
    )
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
