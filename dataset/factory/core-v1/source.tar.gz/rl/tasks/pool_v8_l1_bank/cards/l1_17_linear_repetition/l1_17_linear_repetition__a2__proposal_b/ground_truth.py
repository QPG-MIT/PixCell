import json
from pathlib import Path

import gdsfactory as gf

count = 5
pitch_um = 19.38
layer = (1, 0)


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    for index in range(count):
        item = c << gf.components.L(
            width=3.5, size=(9.0, 12.0), layer=layer
        )
        item.move((index * pitch_um, 0))
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
