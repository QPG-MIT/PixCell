import json
from pathlib import Path

import gdsfactory as gf

layer = (1, 0)
ring_radius_um = 16.0
ring_width_um = 4.0
ellipse_radius_x_um = 8.0
ellipse_radius_y_um = 5.0
center_x_um = 3.0
center_y_um = -2.0


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    ring = c << gf.components.ring(
        radius=ring_radius_um, width=ring_width_um, layer=layer
    )
    ellipse = c << gf.components.ellipse(
        radii=(ellipse_radius_x_um, ellipse_radius_y_um), layer=layer
    )
    ring.move((center_x_um, center_y_um))
    ellipse.move((center_x_um, center_y_um))

    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
