import json
from pathlib import Path

import gdsfactory as gf

count = 6
pitch_um = 13.68
layer = (1, 0)


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    for index in range(count):
        height_um = 9.0 + index * 4.5
        bar = c << gf.components.rectangle(
            size=(5.5, height_um), layer=layer, centered=True
        )
        bar.move((index * pitch_um, height_um / 2))
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
