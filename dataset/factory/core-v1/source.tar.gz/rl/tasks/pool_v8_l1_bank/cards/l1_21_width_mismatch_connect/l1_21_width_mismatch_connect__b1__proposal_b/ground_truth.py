import json
from pathlib import Path

import gdsfactory as gf

narrow_um = 3.99
wide_um = 13.68
layer = (1, 0)


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    xs1 = gf.cross_section.cross_section(
        width=narrow_um, layer=layer, radius=8.0, radius_min=1.0
    )
    xs2 = gf.cross_section.cross_section(
        width=wide_um, layer=layer, radius=8.0, radius_min=1.0
    )
    first = c << gf.components.straight(length=24.0, cross_section=xs1)
    second = c << gf.components.bend_s(
        size=(34.0, 17.0), cross_section=xs2
    )
    second.connect(
        "o1", first.ports["o2"], allow_width_mismatch=True
    )
    c.add_port("o1", port=first.ports["o1"])
    c.add_port("o2", port=second.ports["o2"])
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
