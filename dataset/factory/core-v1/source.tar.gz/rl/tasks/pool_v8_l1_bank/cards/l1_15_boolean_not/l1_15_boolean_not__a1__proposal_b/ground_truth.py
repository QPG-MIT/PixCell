import json
from pathlib import Path

import gdsfactory as gf

wall_um = 5.7
layer = (1, 0)


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    outer = gf.components.rectangle(
        size=(38.0, 27.0), layer=layer, centered=True
    )
    inner = gf.components.rectangle(
        size=(38.0 - 2 * wall_um, 27.0 - 2 * wall_um),
        layer=layer, centered=True
    )
    result = c << gf.boolean(
        A=outer, B=inner, operation="not", layer=layer
    )
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
