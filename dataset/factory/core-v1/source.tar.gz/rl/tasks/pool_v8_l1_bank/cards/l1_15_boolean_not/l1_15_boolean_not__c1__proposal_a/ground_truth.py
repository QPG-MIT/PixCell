import json
from pathlib import Path

import gdsfactory as gf

hole_offset_um = 8.0
layer = (1, 0)


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    outer = gf.components.regular_polygon(
        sides=8, side_length=15.0, layer=layer
    )
    cutters = gf.Component()
    left = cutters << gf.components.circle(radius=4.5, layer=layer)
    right = cutters << gf.components.circle(radius=4.5, layer=layer)
    left.move((-hole_offset_um, 0))
    right.move((hole_offset_um, 0))
    result = c << gf.boolean(
        A=outer, B=cutters, operation="not", layer=layer
    )
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
