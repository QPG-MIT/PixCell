import json
from pathlib import Path

import gdsfactory as gf

ellipse_dx_um = 10.0
layer = (1, 0)
pose_rotation_deg = 135.0


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    pose_scene = gf.Component()
    polygon = gf.components.regular_polygon(
        sides=6, side_length=15.0, layer=layer
    )
    ellipse_parent = gf.Component()
    ellipse = ellipse_parent << gf.components.ellipse(
        radii=(16.0, 10.0), layer=layer
    )
    ellipse.move((ellipse_dx_um, 0))
    result = pose_scene << gf.boolean(
        A=polygon, B=ellipse_parent, operation="xor", layer=layer
    )
    pose_ref = c << pose_scene
    pose_ref.rotate(pose_rotation_deg)
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
