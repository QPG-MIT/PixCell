import json
from pathlib import Path

import gdsfactory as gf

layer = (1, 0)
rail_length_um = 46.0
rail_height_um = 6.0
gap_um = 5.0


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    for row in range(3):
        ref = c << gf.components.rectangle(
            size=(rail_length_um, rail_height_um),
            layer=layer,
            centered=True,
        )
        ref.move((0, (row - 1) * (rail_height_um + gap_um)))

    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
