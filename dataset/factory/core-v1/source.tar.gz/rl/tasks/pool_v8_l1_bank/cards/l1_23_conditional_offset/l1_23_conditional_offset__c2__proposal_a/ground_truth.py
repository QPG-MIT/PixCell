import json
from pathlib import Path

import gdsfactory as gf

count = 9
pitch_um = 11.0
offset_um = 8.0
layer = (1, 0)


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    for index in range(count):
        distance = abs(index - (count - 1) / 2)
        y_um = offset_um if distance >= 3 else -offset_um
        item = c << gf.components.circle(radius=3.6, layer=layer)
        item.move((index * pitch_um, y_um))
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
