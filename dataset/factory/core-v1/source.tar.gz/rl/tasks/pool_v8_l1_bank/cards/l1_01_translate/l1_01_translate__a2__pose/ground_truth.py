import json
from pathlib import Path

import gdsfactory as gf

layer = (1, 0)
block_length_um = 22.0
block_width_um = 8.0
disk_radius_um = 5.5
disk_offset_x_um = 7.0
disk_offset_y_um = 8.5
translation_x_um = 38.0
translation_y_um = 12.0
pose_rotation_deg = 45.0


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    pose_scene = gf.Component()
    unit = gf.Component()
    block = unit << gf.components.rectangle(
        size=(block_length_um, block_width_um),
        layer=layer,
        centered=True,
    )
    disk = unit << gf.components.circle(radius=disk_radius_um, layer=layer)
    disk.move((disk_offset_x_um, disk_offset_y_um))
    original = pose_scene << unit
    original.move((-translation_x_um / 2, -translation_y_um / 2))
    ref = pose_scene << unit
    ref.move((translation_x_um / 2, translation_y_um / 2))
    pose_ref = c << pose_scene
    pose_ref.rotate(pose_rotation_deg)
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
