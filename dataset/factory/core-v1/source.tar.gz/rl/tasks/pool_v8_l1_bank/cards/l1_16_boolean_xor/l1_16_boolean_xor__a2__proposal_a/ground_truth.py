import json
from pathlib import Path

import gdsfactory as gf

separation_um = 12.0
layer = (1, 0)


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    left_parent = gf.Component()
    left = left_parent << gf.components.circle(radius=15.0, layer=layer)
    left.move((-separation_um / 2, 0))
    right_parent = gf.Component()
    right = right_parent << gf.components.circle(radius=10.0, layer=layer)
    right.move((separation_um / 2, 2.0))
    result = c << gf.boolean(
        A=left_parent, B=right_parent, operation="xor", layer=layer
    )
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
