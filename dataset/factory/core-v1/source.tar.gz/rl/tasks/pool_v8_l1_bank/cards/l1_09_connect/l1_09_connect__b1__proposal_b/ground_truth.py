import json
from pathlib import Path

import gdsfactory as gf

layer = (1, 0)
narrow_width_um = 4.56
wide_width_um = 13.68
taper_length_um = 31.92
tail_length_um = 29.64
default_bend_radius_um = 11.4
minimum_bend_radius_um = 2.28


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    taper = c << gf.components.taper(
        length=taper_length_um,
        width1=narrow_width_um,
        width2=wide_width_um,
        layer=layer,
        with_bbox=False,
    )
    xs = gf.cross_section.cross_section(
        width=wide_width_um,
        layer=layer,
        radius=default_bend_radius_um,
        radius_min=minimum_bend_radius_um,
    )
    ref = c << gf.components.straight(
        length=tail_length_um, cross_section=xs
    )
    ref.connect("o1", taper.ports["o2"])
    c.add_port("o1", port=taper.ports["o1"])
    c.add_port("o2", port=ref.ports["o2"])

    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
