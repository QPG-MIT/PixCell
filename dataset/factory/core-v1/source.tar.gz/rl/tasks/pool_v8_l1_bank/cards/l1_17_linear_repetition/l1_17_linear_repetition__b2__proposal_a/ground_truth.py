import json
from pathlib import Path

import gdsfactory as gf

count = 7
pitch_um = 11.0
layer = (1, 0)


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    for index in range(count):
        item = c << gf.components.circle(radius=3.3, layer=layer)
        item.move((index * pitch_um, 0))
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
