import json
from pathlib import Path

import gdsfactory as gf

layer = (1, 0)
triangle_x_um = 19.38
triangle_y_um = 27.36
angle_deg = 63.0
separation_x_um = 43.32


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    original = c << gf.components.triangle(
        x=triangle_x_um, y=triangle_y_um, layer=layer
    )
    original.move((-separation_x_um / 2, 0))
    ref = c << gf.components.triangle(
        x=triangle_x_um, y=triangle_y_um, layer=layer
    )
    ref.rotate(angle_deg)
    ref.move((separation_x_um / 2, 0))

    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
