import json
from pathlib import Path

import gdsfactory as gf

ellipse_dx_um = 11.4
ellipse_dy_um = 7.98
layer = (1, 0)


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    elbow = gf.components.L(width=8.0, size=(31.0, 33.0), layer=layer)
    ellipse_parent = gf.Component()
    ellipse = ellipse_parent << gf.components.ellipse(
        radii=(15.0, 10.0), layer=layer
    )
    ellipse.move((ellipse_dx_um, ellipse_dy_um))
    result = c << gf.boolean(
        A=elbow, B=ellipse_parent, operation="xor", layer=layer
    )
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
