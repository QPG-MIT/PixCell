import json
from pathlib import Path

import gdsfactory as gf

layer = (1, 0)
ring_radius_um = 20.52
ring_width_um = 3.99
polygon_side_um = 7.98
center_x_um = 2.28
center_y_um = 1.14


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    ring = c << gf.components.ring(
        radius=ring_radius_um, width=ring_width_um, layer=layer
    )
    polygon = c << gf.components.regular_polygon(
        sides=6, side_length=polygon_side_um, layer=layer
    )
    ring.move((center_x_um, center_y_um))
    polygon.move((center_x_um, center_y_um))

    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
