import json
from pathlib import Path

import gdsfactory as gf

count = 7
pitch_um = 9.0
layer = (1, 0)


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    for index in range(count):
        dot = c << gf.components.circle(radius=3.2, layer=layer)
        dot.move((0, index * pitch_um))
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
