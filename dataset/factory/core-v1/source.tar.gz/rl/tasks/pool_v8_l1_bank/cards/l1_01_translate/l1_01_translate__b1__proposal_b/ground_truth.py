import json
from pathlib import Path

import gdsfactory as gf

layer = (1, 0)
radius_x_um = 10.26
radius_y_um = 5.7
step_x_um = 28.5
step_y_um = 13.68


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    for index in range(3):
        ref = c << gf.components.ellipse(
            radii=(radius_x_um, radius_y_um), layer=layer
        )
        ref.move((
            (index - 1) * step_x_um,
            (index - 1) * step_y_um,
        ))

    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
