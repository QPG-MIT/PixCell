import json
from pathlib import Path

import gdsfactory as gf

count = 5
pitch_um = 17.0
layer = (1, 0)
pose_rotation_deg = 45.0


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    pose_scene = gf.Component()
    for index in range(count):
        item = pose_scene << gf.components.L(
            width=3.5, size=(9.0, 12.0), layer=layer
        )
        item.move((index * pitch_um, 0))
    pose_ref = c << pose_scene
    pose_ref.rotate(pose_rotation_deg)
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
