import json
from pathlib import Path

import gdsfactory as gf

layer = (1, 0)
width_um = 4.0
default_bend_radius_um = 10.0
minimum_bend_radius_um = 2.0
lead_length_um = 21.0
offset_x_um = 32.0
offset_y_um = 16.0
tail_length_um = 24.0
pose_rotation_deg = 45.0


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    pose_scene = gf.Component()
    xs = gf.cross_section.cross_section(
        width=width_um,
        layer=layer,
        radius=default_bend_radius_um,
        radius_min=minimum_bend_radius_um,
    )
    lead = pose_scene << gf.components.straight(
        length=lead_length_um, cross_section=xs
    )
    middle = pose_scene << gf.components.bend_s(
        size=(offset_x_um, offset_y_um), cross_section=xs
    )
    ref = pose_scene << gf.components.straight(
        length=tail_length_um, cross_section=xs
    )
    middle.connect("o1", lead.ports["o2"])
    ref.connect("o1", middle.ports["o2"])
    pose_scene.add_port("o1", port=lead.ports["o1"])
    pose_scene.add_port("o2", port=ref.ports["o2"])
    pose_ref = c << pose_scene
    pose_ref.rotate(pose_rotation_deg)
    c.add_port("o1", port=pose_ref.ports["o1"])
    c.add_port("o2", port=pose_ref.ports["o2"])
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
