import json
from pathlib import Path

import gdsfactory as gf

count = 10
pitch_um = 11.4
offset_um = 12.54
layer = (1, 0)


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    for index in range(count):
        y_um = offset_um if index % 3 == 0 else 0.0
        item = c << gf.components.rectangle(
            size=(5.0, 12.0), layer=layer, centered=True
        )
        item.move((index * pitch_um, y_um))
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
