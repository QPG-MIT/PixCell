import json
from pathlib import Path

import gdsfactory as gf

layer = (1, 0)
rail_length_um = 52.44
rail_height_um = 6.84
lower_gap_um = 4.56
upper_gap_um = 10.26


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    lower = c << gf.components.rectangle(
        size=(rail_length_um, rail_height_um),
        layer=layer,
        centered=True,
    )
    middle = c << gf.components.rectangle(
        size=(rail_length_um, rail_height_um),
        layer=layer,
        centered=True,
    )
    upper = c << gf.components.rectangle(
        size=(rail_length_um, rail_height_um),
        layer=layer,
        centered=True,
    )
    lower.move((0, -rail_height_um - lower_gap_um))
    upper.move((0, rail_height_um + upper_gap_um))

    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
