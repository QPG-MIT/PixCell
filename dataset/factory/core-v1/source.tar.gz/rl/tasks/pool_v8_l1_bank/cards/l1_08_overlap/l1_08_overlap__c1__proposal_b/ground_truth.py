import json
from pathlib import Path

import gdsfactory as gf

layer = (1, 0)
bar_length_um = 35.34
bar_height_um = 10.26
step_um = 18.24


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    angles_deg = (-24.0, 0.0, 24.0)
    for index, angle_deg in enumerate(angles_deg):
        ref = c << gf.components.rectangle(
            size=(bar_length_um, bar_height_um),
            layer=layer,
            centered=True,
        )
        ref.rotate(angle_deg)
        ref.move(((index - 1) * step_um, (index - 1) * 4.0))

    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
