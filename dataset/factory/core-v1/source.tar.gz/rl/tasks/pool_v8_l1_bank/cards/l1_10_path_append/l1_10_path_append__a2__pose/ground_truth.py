import json
from pathlib import Path

import gdsfactory as gf

layer = (1, 0)
width_um = 4.0
minimum_bend_radius_um = 1.0
leg_um = 19.0
radius_um = 11.0
angle_deg = 62.0
pose_rotation_deg = 45.0


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    pose_scene = gf.Component()
    path = gf.Path()
    path.append(gf.path.arc(radius=radius_um, angle=angle_deg))
    path.append(gf.path.straight(length=leg_um))
    path.append(gf.path.arc(radius=radius_um, angle=angle_deg))
    xs = gf.cross_section.cross_section(
        width=width_um,
        layer=layer,
        radius=radius_um,
        radius_min=minimum_bend_radius_um,
    )
    ref = pose_scene << gf.path.extrude(p=path, cross_section=xs)
    pose_ref = c << pose_scene
    pose_ref.rotate(pose_rotation_deg)
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
