import json
from pathlib import Path

import gdsfactory as gf

count = 8
pitch_um = 12.54
offset_um = 9.12
layer = (1, 0)


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    for index in range(count):
        y_um = -offset_um if index < count / 2 else offset_um
        item = c << gf.components.rectangle(
            size=(5.0, 12.0), layer=layer, centered=True
        )
        item.move((index * pitch_um, y_um))
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
