import json
from pathlib import Path

import gdsfactory as gf

count = 9
pitch_um = 11.0
offset_um = 10.0
layer = (1, 0)


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    for index in range(count):
        is_endpoint = index == 0 or index == count - 1
        y_um = offset_um if is_endpoint else 0.0
        item = c << gf.components.triangle(x=7.0, y=10.0, layer=layer)
        item.move((index * pitch_um, y_um))
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
