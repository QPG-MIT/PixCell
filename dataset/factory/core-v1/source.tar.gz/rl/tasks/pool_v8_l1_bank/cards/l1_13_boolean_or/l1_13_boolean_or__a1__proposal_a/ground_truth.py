import json
from pathlib import Path

import gdsfactory as gf

offset_x_um = 12.0
layer = (1, 0)


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    bar = gf.components.rectangle(
        size=(34.0, 14.0), layer=layer, centered=True
    )
    disk_parent = gf.Component()
    disk = disk_parent << gf.components.circle(radius=12.0, layer=layer)
    disk.move((offset_x_um, 0))
    result = c << gf.boolean(
        A=bar, B=disk_parent, operation="or", layer=layer
    )
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
