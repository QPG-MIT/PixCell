import json
from pathlib import Path

import gdsfactory as gf

layer = (1, 0)
arm_width_um = 6.0
size_x_um = 25.0
size_y_um = 29.0
taper_length_um = 31.0
narrow_width_um = 4.0
wide_width_um = 12.0
shared_right_um = 18.0
vertical_offset_um = 15.0


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    elbow = c << gf.components.L(
        width=arm_width_um, size=(size_x_um, size_y_um), layer=layer
    )
    taper = c << gf.components.taper(
        length=taper_length_um,
        width1=narrow_width_um,
        width2=wide_width_um,
        layer=layer,
        with_bbox=False,
    )
    elbow.move((shared_right_um - elbow.xmax, vertical_offset_um))
    taper.move((shared_right_um - taper.xmax, -vertical_offset_um))

    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
