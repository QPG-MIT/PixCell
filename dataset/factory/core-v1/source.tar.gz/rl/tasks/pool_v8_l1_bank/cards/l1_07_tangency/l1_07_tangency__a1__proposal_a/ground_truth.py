import json
from pathlib import Path

import gdsfactory as gf

layer = (1, 0)
left_radius_um = 12.0
right_radius_um = 8.0


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    left = c << gf.components.circle(radius=left_radius_um, layer=layer)
    right = c << gf.components.circle(radius=right_radius_um, layer=layer)
    right.move((left_radius_um + right_radius_um, 0))

    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
