import json
from pathlib import Path

import gdsfactory as gf

count = 7
pitch_um = 9.0
layer = (1, 0)
pose_rotation_deg = 135.0


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    pose_scene = gf.Component()
    for index in range(count):
        dot = pose_scene << gf.components.circle(radius=3.2, layer=layer)
        dot.move((0, index * pitch_um))
    pose_ref = c << pose_scene
    pose_ref.rotate(pose_rotation_deg)
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
