import json
from pathlib import Path

import gdsfactory as gf

layer = (1, 0)
arm_width_um = 5.0
size_x_um = 22.0
size_y_um = 26.0
taper_length_um = 28.0
narrow_width_um = 3.5
wide_width_um = 11.0
ellipse_radius_x_um = 9.0
ellipse_radius_y_um = 5.0
shared_right_um = 20.0
row_pitch_um = 24.0


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    elbow = c << gf.components.L(
        width=arm_width_um, size=(size_x_um, size_y_um), layer=layer
    )
    taper = c << gf.components.taper(
        length=taper_length_um,
        width1=narrow_width_um,
        width2=wide_width_um,
        layer=layer,
        with_bbox=False,
    )
    ellipse = c << gf.components.ellipse(
        radii=(ellipse_radius_x_um, ellipse_radius_y_um), layer=layer
    )
    elbow.move((shared_right_um - elbow.xmax, row_pitch_um))
    taper.move((shared_right_um - taper.xmax, 0))
    ellipse.move((
        shared_right_um - ellipse.xmax,
        -row_pitch_um,
    ))

    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
