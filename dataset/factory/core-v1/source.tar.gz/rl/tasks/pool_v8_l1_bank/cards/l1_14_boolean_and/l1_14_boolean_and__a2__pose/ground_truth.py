import json
from pathlib import Path

import gdsfactory as gf

ellipse_dx_um = 7.0
layer = (1, 0)
pose_rotation_deg = 45.0


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    pose_scene = gf.Component()
    triangle = gf.components.triangle(x=32.0, y=27.0, layer=layer)
    ellipse_parent = gf.Component()
    ellipse = ellipse_parent << gf.components.ellipse(
        radii=(18.0, 12.0), layer=layer
    )
    ellipse.move((ellipse_dx_um, 5.0))
    result = pose_scene << gf.boolean(
        A=triangle, B=ellipse_parent, operation="and", layer=layer
    )
    pose_ref = c << pose_scene
    pose_ref.rotate(pose_rotation_deg)
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
