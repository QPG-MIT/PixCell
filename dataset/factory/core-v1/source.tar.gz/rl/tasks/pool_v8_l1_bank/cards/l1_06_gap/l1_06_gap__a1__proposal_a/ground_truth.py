import json
from pathlib import Path

import gdsfactory as gf

layer = (1, 0)
default_bend_radius_um = 8.0
minimum_bend_radius_um = 1.0
rail_length_um = 48.0
rail_width_um = 4.0
gap_um = 4.5


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    xs = gf.cross_section.cross_section(
        width=rail_width_um,
        layer=layer,
        radius=default_bend_radius_um,
        radius_min=minimum_bend_radius_um,
    )
    lower = c << gf.components.straight(
        length=rail_length_um, cross_section=xs
    )
    upper = c << gf.components.straight(
        length=rail_length_um, cross_section=xs
    )
    upper.move((0, rail_width_um + gap_um))

    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
