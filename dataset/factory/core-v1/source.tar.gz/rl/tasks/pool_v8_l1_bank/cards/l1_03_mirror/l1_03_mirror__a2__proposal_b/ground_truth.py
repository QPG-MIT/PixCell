import json
from pathlib import Path

import gdsfactory as gf

layer = (1, 0)
triangle_x_um = 20.52
triangle_y_um = 30.78
separation_x_um = 45.6
vertical_offset_um = 7.98


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    original = c << gf.components.triangle(
        x=triangle_x_um, y=triangle_y_um, layer=layer
    )
    original.move((-separation_x_um / 2, vertical_offset_um))
    ref = c << gf.components.triangle(
        x=triangle_x_um, y=triangle_y_um, layer=layer
    )
    ref.mirror()
    ref.move((separation_x_um / 2, -vertical_offset_um))

    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
