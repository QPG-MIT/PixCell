import json
from pathlib import Path

import gdsfactory as gf

wide1_um = 11.0
narrow_um = 4.0
wide2_um = 9.0
layer = (1, 0)
pose_rotation_deg = 45.0


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    pose_scene = gf.Component()
    xs1 = gf.cross_section.cross_section(
        width=wide1_um, layer=layer, radius=8.0, radius_min=1.0
    )
    xs2 = gf.cross_section.cross_section(
        width=narrow_um, layer=layer, radius=8.0, radius_min=1.0
    )
    xs3 = gf.cross_section.cross_section(
        width=wide2_um, layer=layer, radius=8.0, radius_min=1.0
    )
    first = pose_scene << gf.components.straight(length=23.0, cross_section=xs1)
    middle = pose_scene << gf.components.straight(length=25.0, cross_section=xs2)
    last = pose_scene << gf.components.straight(length=23.0, cross_section=xs3)
    middle.connect("o1", first.ports["o2"], allow_width_mismatch=True)
    last.connect("o1", middle.ports["o2"], allow_width_mismatch=True)
    pose_scene.add_port("o1", port=first.ports["o1"])
    pose_scene.add_port("o2", port=last.ports["o2"])
    pose_ref = c << pose_scene
    pose_ref.rotate(pose_rotation_deg)
    c.add_port("o1", port=pose_ref.ports["o1"])
    c.add_port("o2", port=pose_ref.ports["o2"])
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
