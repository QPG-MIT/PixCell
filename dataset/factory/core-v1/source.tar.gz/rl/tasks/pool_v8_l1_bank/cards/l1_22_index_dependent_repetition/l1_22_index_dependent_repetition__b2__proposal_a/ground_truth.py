import json
from pathlib import Path

import gdsfactory as gf

count = 8
pitch_um = 12.0
layer = (1, 0)


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    for index in range(count):
        height_um = 20.0 if index % 2 else 9.0
        item = c << gf.components.rectangle(
            size=(5.0, height_um), layer=layer, centered=True
        )
        item.move((index * pitch_um, height_um / 2))
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
