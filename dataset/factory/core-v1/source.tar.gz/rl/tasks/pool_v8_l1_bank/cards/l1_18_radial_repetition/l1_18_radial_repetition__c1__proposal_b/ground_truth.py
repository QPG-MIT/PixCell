import json
from pathlib import Path

import gdsfactory as gf

count = 7
orbit_um = 28.5
layer = (1, 0)


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    import math
    for index in range(count):
        angle_deg = -90 + index * 180 / (count - 1)
        angle_rad = math.radians(angle_deg)
        dot = c << gf.components.circle(radius=3.6, layer=layer)
        dot.move((
            orbit_um * math.cos(angle_rad),
            orbit_um * math.sin(angle_rad),
        ))
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
