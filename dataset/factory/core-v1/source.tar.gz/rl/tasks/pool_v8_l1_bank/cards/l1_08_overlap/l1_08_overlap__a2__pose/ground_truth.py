import json
from pathlib import Path

import gdsfactory as gf

layer = (1, 0)
bar_length_um = 38.0
bar_height_um = 9.0
ellipse_radius_x_um = 16.0
ellipse_radius_y_um = 6.0
angle_deg = 31.0
offset_x_um = 7.0
pose_rotation_deg = 45.0


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    pose_scene = gf.Component()
    bar = pose_scene << gf.components.rectangle(
        size=(bar_length_um, bar_height_um), layer=layer, centered=True
    )
    bar.rotate(angle_deg)
    ellipse = pose_scene << gf.components.ellipse(
        radii=(ellipse_radius_x_um, ellipse_radius_y_um), layer=layer
    )
    ellipse.rotate(-angle_deg)
    ellipse.move((offset_x_um, 0))
    pose_ref = c << pose_scene
    pose_ref.rotate(pose_rotation_deg)
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
