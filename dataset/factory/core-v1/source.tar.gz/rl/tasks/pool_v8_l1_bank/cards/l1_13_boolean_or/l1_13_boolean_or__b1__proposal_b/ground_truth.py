import json
from pathlib import Path

import gdsfactory as gf

offset_x_um = 9.12
offset_y_um = 4.56
layer = (1, 0)


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    elbow = gf.components.L(
        width=7.0, size=(28.0, 31.0), layer=layer
    )
    ellipse_parent = gf.Component()
    ellipse = ellipse_parent << gf.components.ellipse(
        radii=(14.0, 9.0), layer=layer
    )
    ellipse.move((offset_x_um, offset_y_um))
    result = c << gf.boolean(
        A=elbow, B=ellipse_parent, operation="or", layer=layer
    )
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
