import json
from pathlib import Path

import gdsfactory as gf

layer = (1, 0)
top_length_um = 39.0
top_height_um = 8.0
bottom_length_um = 25.0
bottom_height_um = 13.0
shared_x_um = -18.0
vertical_gap_um = 8.0


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    top = c << gf.components.rectangle(
        size=(top_length_um, top_height_um), layer=layer, centered=False
    )
    bottom = c << gf.components.rectangle(
        size=(bottom_length_um, bottom_height_um),
        layer=layer,
        centered=False,
    )
    top.move((shared_x_um, vertical_gap_um))
    bottom.move((shared_x_um, -bottom_height_um - vertical_gap_um))

    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
