import json
from pathlib import Path

import gdsfactory as gf

layer = (1, 0)
default_bend_radius_um = 8.0
minimum_bend_radius_um = 1.0
bus_length_um = 56.0
width_um = 4.0
ring_radius_um = 14.0
gap_um = 5.0
pose_rotation_deg = 135.0


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    pose_scene = gf.Component()
    xs = gf.cross_section.cross_section(
        width=width_um,
        layer=layer,
        radius=default_bend_radius_um,
        radius_min=minimum_bend_radius_um,
    )
    bus = pose_scene << gf.components.straight(
        length=bus_length_um, cross_section=xs
    )
    ring = pose_scene << gf.components.ring(
        radius=ring_radius_um, width=width_um, layer=layer
    )
    ring.move((bus_length_um / 2, bus.ymax + gap_um - ring.ymin))
    pose_ref = c << pose_scene
    pose_ref.rotate(pose_rotation_deg)
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
