import json
from pathlib import Path

import gdsfactory as gf

layer = (1, 0)
ring_radius_um = 19.38
ring_width_um = 3.99
cross_length_um = 15.96
cross_width_um = 4.56
center_x_um = -2.28
center_y_um = 3.42


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    ring = c << gf.components.ring(
        radius=ring_radius_um, width=ring_width_um, layer=layer
    )
    cross = c << gf.components.cross(
        length=cross_length_um, width=cross_width_um, layer=layer
    )
    ring.move((center_x_um, center_y_um))
    cross.move((center_x_um, center_y_um))

    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
