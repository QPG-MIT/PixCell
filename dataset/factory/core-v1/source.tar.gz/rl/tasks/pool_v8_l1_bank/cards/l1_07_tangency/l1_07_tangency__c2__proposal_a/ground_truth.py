import json
from pathlib import Path

import gdsfactory as gf

layer = (1, 0)
bar_length_um = 28.0
bar_height_um = 8.0
disk_radius_um = 7.0


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    bar = c << gf.components.rectangle(
        size=(bar_length_um, bar_height_um), layer=layer, centered=True
    )
    left = c << gf.components.circle(radius=disk_radius_um, layer=layer)
    right = c << gf.components.circle(radius=disk_radius_um, layer=layer)
    contact_x_um = bar_length_um / 2 + disk_radius_um
    left.move((-contact_x_um, 0))
    right.move((contact_x_um, 0))

    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
