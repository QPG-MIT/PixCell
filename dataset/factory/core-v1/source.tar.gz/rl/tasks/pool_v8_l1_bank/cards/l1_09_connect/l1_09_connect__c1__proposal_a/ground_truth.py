import json
from pathlib import Path

import gdsfactory as gf

layer = (1, 0)
width_um = 4.0
default_bend_radius_um = 10.0
minimum_bend_radius_um = 2.0
lead_length_um = 22.0
bend_radius_um = 13.0
bend_angle_deg = 90.0
tail_length_um = 25.0


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    xs = gf.cross_section.cross_section(
        width=width_um,
        layer=layer,
        radius=bend_radius_um,
        radius_min=minimum_bend_radius_um,
    )
    lead = c << gf.components.straight(
        length=lead_length_um, cross_section=xs
    )
    turn = c << gf.components.bend_euler(
        radius=bend_radius_um,
        angle=bend_angle_deg,
        cross_section=xs,
    )
    ref = c << gf.components.straight(
        length=tail_length_um, cross_section=xs
    )
    turn.connect("o1", lead.ports["o2"])
    ref.connect("o1", turn.ports["o2"])
    c.add_port("o1", port=lead.ports["o1"])
    c.add_port("o2", port=ref.ports["o2"])

    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
