import json
from pathlib import Path

import gdsfactory as gf

rows = 5
columns = 3
pitch_x_um = 15.0
pitch_y_um = 13.0
layer = (1, 0)


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    unit = gf.components.cross(length=8.0, width=3.0, layer=layer)
    ref = c.add_ref(
        unit, columns=columns, rows=rows,
        column_pitch=pitch_x_um, row_pitch=pitch_y_um
    )
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
