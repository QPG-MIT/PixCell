import json
from pathlib import Path

import gdsfactory as gf

dx_um = 11.0
dy_um = 10.0
layer = (1, 0)


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    lower = gf.Component()
    left = lower << gf.components.circle(radius=11.0, layer=layer)
    right = lower << gf.components.circle(radius=11.0, layer=layer)
    left.move((-dx_um, -dy_um / 2))
    right.move((dx_um, -dy_um / 2))
    upper_parent = gf.Component()
    upper = upper_parent << gf.components.circle(radius=11.0, layer=layer)
    upper.move((0, dy_um))
    result = c << gf.boolean(
        A=lower, B=upper_parent, operation="or", layer=layer
    )
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
