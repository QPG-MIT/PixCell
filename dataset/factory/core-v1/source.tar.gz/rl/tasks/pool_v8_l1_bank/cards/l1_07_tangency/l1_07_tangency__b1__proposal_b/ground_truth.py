import json
from pathlib import Path

import gdsfactory as gf

layer = (1, 0)
bar_length_um = 41.04
bar_height_um = 13.68
disk_radius_um = 10.26


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    bar = c << gf.components.rectangle(
        size=(bar_length_um, bar_height_um), layer=layer, centered=True
    )
    disk = c << gf.components.circle(radius=disk_radius_um, layer=layer)
    disk.move((bar_length_um / 2 + disk_radius_um, 0))

    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
