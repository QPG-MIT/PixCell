import json
from pathlib import Path

import gdsfactory as gf

ellipse_dx_um = 7.0
layer = (1, 0)


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    triangle = gf.components.triangle(x=32.0, y=27.0, layer=layer)
    ellipse_parent = gf.Component()
    ellipse = ellipse_parent << gf.components.ellipse(
        radii=(18.0, 12.0), layer=layer
    )
    ellipse.move((ellipse_dx_um, 5.0))
    result = c << gf.boolean(
        A=triangle, B=ellipse_parent, operation="and", layer=layer
    )
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
