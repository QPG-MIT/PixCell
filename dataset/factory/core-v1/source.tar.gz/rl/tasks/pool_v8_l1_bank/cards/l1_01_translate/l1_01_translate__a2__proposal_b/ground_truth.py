import json
from pathlib import Path

import gdsfactory as gf

layer = (1, 0)
block_length_um = 25.08
block_width_um = 9.12
disk_radius_um = 6.27
disk_offset_x_um = 7.98
disk_offset_y_um = 9.69
translation_x_um = 43.32
translation_y_um = 13.68


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    unit = gf.Component()
    block = unit << gf.components.rectangle(
        size=(block_length_um, block_width_um),
        layer=layer,
        centered=True,
    )
    disk = unit << gf.components.circle(radius=disk_radius_um, layer=layer)
    disk.move((disk_offset_x_um, disk_offset_y_um))
    original = c << unit
    original.move((-translation_x_um / 2, -translation_y_um / 2))
    ref = c << unit
    ref.move((translation_x_um / 2, translation_y_um / 2))

    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
