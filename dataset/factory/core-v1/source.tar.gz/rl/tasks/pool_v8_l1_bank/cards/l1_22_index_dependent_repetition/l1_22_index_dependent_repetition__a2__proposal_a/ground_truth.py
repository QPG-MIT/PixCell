import json
from pathlib import Path

import gdsfactory as gf

count = 7
pitch_um = 13.0
layer = (1, 0)


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    for index in range(count):
        height_um = 8.0 + 0.75 * index * index
        item = c << gf.components.rectangle(
            size=(5.0, height_um), layer=layer, centered=True
        )
        item.move((index * pitch_um, height_um / 2))
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
