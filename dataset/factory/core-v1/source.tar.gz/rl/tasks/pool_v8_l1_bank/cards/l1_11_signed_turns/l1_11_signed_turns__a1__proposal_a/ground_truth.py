import json
from pathlib import Path

import gdsfactory as gf

layer = (1, 0)
turn_angles_deg = (62.0, 62.0)
leg_um = 14.0
radius_um = 9.0
width_um = 4.0
minimum_bend_radius_um = 1.0


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    path = gf.Path()
    path.append(gf.path.straight(length=leg_um))
    for angle_deg in turn_angles_deg:
        path.append(gf.path.arc(radius=radius_um, angle=angle_deg))
        path.append(gf.path.straight(length=leg_um))
    xs = gf.cross_section.cross_section(
        width=width_um,
        layer=layer,
        radius=radius_um,
        radius_min=minimum_bend_radius_um,
    )
    ref = c << gf.path.extrude(p=path, cross_section=xs)

    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
