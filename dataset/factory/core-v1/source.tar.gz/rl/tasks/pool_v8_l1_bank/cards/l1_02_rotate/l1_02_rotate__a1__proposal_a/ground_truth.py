import json
from pathlib import Path

import gdsfactory as gf

layer = (1, 0)
arm_width_um = 6.0
size_x_um = 20.0
size_y_um = 28.0
angle_deg = 42.0
separation_x_um = 40.0


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    original = c << gf.components.L(
        width=arm_width_um, size=(size_x_um, size_y_um), layer=layer
    )
    original.move((-separation_x_um / 2, 0))
    ref = c << gf.components.L(
        width=arm_width_um, size=(size_x_um, size_y_um), layer=layer
    )
    ref.rotate(angle_deg)
    ref.move((separation_x_um / 2, 0))

    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
