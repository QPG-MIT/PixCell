import json
from pathlib import Path

import gdsfactory as gf

narrow_um = 3.5
wide_um = 12.0
layer = (1, 0)
pose_rotation_deg = 135.0


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    pose_scene = gf.Component()
    xs1 = gf.cross_section.cross_section(
        width=narrow_um, layer=layer, radius=8.0, radius_min=1.0
    )
    xs2 = gf.cross_section.cross_section(
        width=wide_um, layer=layer, radius=8.0, radius_min=1.0
    )
    first = pose_scene << gf.components.straight(length=24.0, cross_section=xs1)
    second = pose_scene << gf.components.bend_s(
        size=(34.0, 17.0), cross_section=xs2
    )
    second.connect(
        "o1", first.ports["o2"], allow_width_mismatch=True
    )
    pose_scene.add_port("o1", port=first.ports["o1"])
    pose_scene.add_port("o2", port=second.ports["o2"])
    pose_ref = c << pose_scene
    pose_ref.rotate(pose_rotation_deg)
    c.add_port("o1", port=pose_ref.ports["o1"])
    c.add_port("o2", port=pose_ref.ports["o2"])
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
