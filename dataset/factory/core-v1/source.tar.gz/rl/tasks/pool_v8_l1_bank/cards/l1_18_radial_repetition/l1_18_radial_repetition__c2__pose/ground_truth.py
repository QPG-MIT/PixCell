import json
from pathlib import Path

import gdsfactory as gf

count = 7
orbit_um = 27.0
span_deg = 210.0
layer = (1, 0)
pose_rotation_deg = 45.0


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    pose_scene = gf.Component()
    import math
    for index in range(count):
        angle_deg = -105.0 + index * span_deg / (count - 1)
        angle_rad = math.radians(angle_deg)
        item = pose_scene << gf.components.L(
            width=3.0, size=(8.0, 11.0), layer=layer
        )
        item.rotate(angle_deg - 90.0)
        item.move((
            orbit_um * math.cos(angle_rad),
            orbit_um * math.sin(angle_rad),
        ))
    pose_ref = c << pose_scene
    pose_ref.rotate(pose_rotation_deg)
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
