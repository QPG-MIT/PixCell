import json
from pathlib import Path

import gdsfactory as gf

layer = (1, 0)
narrow_width_um = 4.0
wide_width_um = 11.0
taper_length_um = 27.0
bend_radius_um = 14.0
bend_angle_deg = 70.0
minimum_bend_radius_um = 2.0


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    taper = c << gf.components.taper(
        length=taper_length_um,
        width1=narrow_width_um,
        width2=wide_width_um,
        layer=layer,
        with_bbox=False,
    )
    xs = gf.cross_section.cross_section(
        width=wide_width_um,
        layer=layer,
        radius=bend_radius_um,
        radius_min=minimum_bend_radius_um,
    )
    ref = c << gf.components.bend_euler(
        radius=bend_radius_um,
        angle=bend_angle_deg,
        cross_section=xs,
    )
    ref.connect("o1", taper.ports["o2"])
    c.add_port("o1", port=taper.ports["o1"])
    c.add_port("o2", port=ref.ports["o2"])

    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
