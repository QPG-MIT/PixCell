import json
from pathlib import Path

import gdsfactory as gf

layer = (1, 0)
taper_length_um = 25.0
narrow_width_um = 4.0
wide_width_um = 11.0
disk_radius_um = 4.5
disk_offset_x_um = 6.0
disk_offset_y_um = 9.0
angle_deg = 125.0
separation_x_um = 48.0


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    unit = gf.Component()
    taper = unit << gf.components.taper(
        length=taper_length_um,
        width1=narrow_width_um,
        width2=wide_width_um,
        layer=layer,
        with_bbox=False,
    )
    disk = unit << gf.components.circle(radius=disk_radius_um, layer=layer)
    disk.move((disk_offset_x_um, disk_offset_y_um))
    original = c << unit
    original.move((-separation_x_um / 2, 0))
    ref = c << unit
    ref.rotate(angle_deg)
    ref.move((separation_x_um / 2, 0))

    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
