import json
from pathlib import Path

import gdsfactory as gf

layer = (1, 0)
lengths_um = (42.0, 30.0, 20.0)
heights_um = (7.0, 10.0, 13.0)
shared_x_um = -22.8
row_pitch_um = 22.8


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    for index, (length_um, height_um) in enumerate(
        zip(lengths_um, heights_um, strict=True)
    ):
        ref = c << gf.components.rectangle(
            size=(length_um, height_um), layer=layer, centered=False
        )
        ref.move((shared_x_um, (index - 1) * row_pitch_um))

    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
