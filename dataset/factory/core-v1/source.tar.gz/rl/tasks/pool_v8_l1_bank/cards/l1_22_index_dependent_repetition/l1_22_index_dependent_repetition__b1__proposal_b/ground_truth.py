import json
from pathlib import Path

import gdsfactory as gf

count = 7
pitch_um = 14.82
layer = (1, 0)


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    for index in range(count):
        distance = abs(index - (count - 1) / 2)
        radius_um = 7.0 - 1.0 * distance
        item = c << gf.components.circle(radius=radius_um, layer=layer)
        item.move((index * pitch_um, 0))
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
