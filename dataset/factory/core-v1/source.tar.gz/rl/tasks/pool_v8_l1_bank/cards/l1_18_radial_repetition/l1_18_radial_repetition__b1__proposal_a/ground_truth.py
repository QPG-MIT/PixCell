import json
from pathlib import Path

import gdsfactory as gf

count = 6
orbit_um = 23.0
layer = (1, 0)


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    import math
    for index in range(count):
        angle_deg = index * 360 / count
        angle_rad = math.radians(angle_deg)
        bar = c << gf.components.rectangle(
            size=(5.0, 14.0), layer=layer, centered=True
        )
        bar.rotate(angle_deg)
        bar.move((
            orbit_um * math.cos(angle_rad),
            orbit_um * math.sin(angle_rad),
        ))
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
