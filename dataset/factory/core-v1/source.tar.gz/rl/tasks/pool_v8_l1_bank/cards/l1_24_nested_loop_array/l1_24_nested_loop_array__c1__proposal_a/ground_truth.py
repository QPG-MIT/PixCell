import json
from pathlib import Path

import gdsfactory as gf

rows = 4
columns = 3
pitch_x_um = 15.0
pitch_y_um = 11.0
layer = (1, 0)


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    for row in range(rows):
        for column in range(columns):
            item = c << gf.components.rectangle(
                size=(7.0, 5.0), layer=layer, centered=True
            )
            item.move((
                column * pitch_x_um,
                row * pitch_y_um,
            ))
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
