import json
from pathlib import Path

import gdsfactory as gf

angle_deg = 28.0
layer = (1, 0)


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    first_parent = gf.Component()
    first = first_parent << gf.components.rectangle(
        size=(42.0, 13.0), layer=layer, centered=True
    )
    first.rotate(angle_deg)
    second_parent = gf.Component()
    second = second_parent << gf.components.rectangle(
        size=(42.0, 13.0), layer=layer, centered=True
    )
    second.rotate(-angle_deg)
    result = c << gf.boolean(
        A=first_parent, B=second_parent,
        operation="xor", layer=layer
    )
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
