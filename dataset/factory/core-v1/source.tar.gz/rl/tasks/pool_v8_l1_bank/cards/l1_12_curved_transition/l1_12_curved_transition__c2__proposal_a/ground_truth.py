import json
from pathlib import Path

import gdsfactory as gf

layer = (1, 0)
waypoints_um = ((0.0, 0.0), (13.0, 0.0), (24.0, 11.0), (39.0, 16.0), (52.0, 16.0))
path_bend_radius_um = 4.5
narrow_width_um = 3.0
wide_width_um = 15.0
width_type = 'parabolic'
default_bend_radius_um = 8.0
minimum_bend_radius_um = 1.0


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    path = gf.path.smooth(
        waypoints_um,
        radius=path_bend_radius_um,
    )
    narrow_xs = gf.cross_section.cross_section(
        width=narrow_width_um,
        layer=layer,
        radius=default_bend_radius_um,
        radius_min=minimum_bend_radius_um,
    )
    wide_xs = gf.cross_section.cross_section(
        width=wide_width_um,
        layer=layer,
        radius=default_bend_radius_um,
        radius_min=minimum_bend_radius_um,
    )
    profile = gf.path.transition(
        cross_section1=narrow_xs,
        cross_section2=wide_xs,
        width_type=width_type,
    )
    ref = c << gf.path.extrude_transition(p=path, transition=profile)

    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
