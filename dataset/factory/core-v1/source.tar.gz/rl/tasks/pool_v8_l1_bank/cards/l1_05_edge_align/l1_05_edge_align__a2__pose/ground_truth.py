import json
from pathlib import Path

import gdsfactory as gf

layer = (1, 0)
lengths_um = (42.0, 30.0, 20.0)
heights_um = (7.0, 10.0, 13.0)
shared_x_um = -20.0
row_pitch_um = 20.0
pose_rotation_deg = 45.0


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    pose_scene = gf.Component()
    for index, (length_um, height_um) in enumerate(
        zip(lengths_um, heights_um, strict=True)
    ):
        ref = pose_scene << gf.components.rectangle(
            size=(length_um, height_um), layer=layer, centered=False
        )
        ref.move((shared_x_um, (index - 1) * row_pitch_um))
    pose_ref = c << pose_scene
    pose_ref.rotate(pose_rotation_deg)
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
