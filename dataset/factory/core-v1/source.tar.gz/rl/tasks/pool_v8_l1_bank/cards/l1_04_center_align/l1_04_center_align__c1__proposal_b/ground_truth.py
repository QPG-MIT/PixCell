import json
from pathlib import Path

import gdsfactory as gf

layer = (1, 0)
outer_radius_um = 23.94
outer_width_um = 3.42
middle_radius_um = 14.25
middle_width_um = 3.42
ellipse_radius_x_um = 6.84
ellipse_radius_y_um = 3.99
center_x_um = 2.28
center_y_um = -1.14


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    outer = c << gf.components.ring(
        radius=outer_radius_um, width=outer_width_um, layer=layer
    )
    middle = c << gf.components.ring(
        radius=middle_radius_um, width=middle_width_um, layer=layer
    )
    ellipse = c << gf.components.ellipse(
        radii=(ellipse_radius_x_um, ellipse_radius_y_um), layer=layer
    )
    outer.move((center_x_um, center_y_um))
    middle.move((center_x_um, center_y_um))
    ellipse.move((center_x_um, center_y_um))

    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
