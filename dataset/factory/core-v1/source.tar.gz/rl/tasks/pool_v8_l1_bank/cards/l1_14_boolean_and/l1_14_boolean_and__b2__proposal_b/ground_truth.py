import json
from pathlib import Path

import gdsfactory as gf

angle_deg = 27.0
offset_um = 4.56
layer = (1, 0)


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    cross = gf.components.cross(length=34.0, width=10.0, layer=layer)
    bar_parent = gf.Component()
    bar = bar_parent << gf.components.rectangle(
        size=(45.0, 13.0), layer=layer, centered=True
    )
    bar.rotate(angle_deg)
    bar.move((offset_um, 0))
    result = c << gf.boolean(
        A=cross, B=bar_parent, operation="and", layer=layer
    )
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
