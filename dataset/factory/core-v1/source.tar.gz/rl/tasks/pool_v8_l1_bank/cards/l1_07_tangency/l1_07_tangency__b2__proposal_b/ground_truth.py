import json
from pathlib import Path

import gdsfactory as gf

layer = (1, 0)
left_length_um = 31.92
left_height_um = 20.52
right_length_um = 26.22
right_height_um = 11.4


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    left = c << gf.components.rectangle(
        size=(left_length_um, left_height_um), layer=layer, centered=True
    )
    right = c << gf.components.rectangle(
        size=(right_length_um, right_height_um), layer=layer, centered=True
    )
    right.move(((left_length_um + right_length_um) / 2, 0))

    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
