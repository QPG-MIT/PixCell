import json
from pathlib import Path

import gdsfactory as gf

count = 6
pitch_um = 14.82
layer = (1, 0)


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    for index in range(count):
        tooth = c << gf.components.triangle(
            x=7.0, y=11.0, layer=layer
        )
        tooth.move((index * pitch_um, 0))
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
