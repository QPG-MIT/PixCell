import json
from pathlib import Path

import gdsfactory as gf

notch_x_um = 18.0
layer = (1, 0)
pose_rotation_deg = 135.0


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    pose_scene = gf.Component()
    outer = gf.components.rectangle(
        size=(44.0, 27.0), layer=layer, centered=True
    )
    cutter_parent = gf.Component()
    cutter = cutter_parent << gf.components.circle(
        radius=9.0, layer=layer
    )
    cutter.move((notch_x_um, 0))
    result = pose_scene << gf.boolean(
        A=outer, B=cutter_parent, operation="not", layer=layer
    )
    pose_ref = c << pose_scene
    pose_ref.rotate(pose_rotation_deg)
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
