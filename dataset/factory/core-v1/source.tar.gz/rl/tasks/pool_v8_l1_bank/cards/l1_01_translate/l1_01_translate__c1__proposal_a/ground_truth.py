import json
from pathlib import Path

import gdsfactory as gf

layer = (1, 0)
arm_width_um = 5.0
size_x_um = 18.0
size_y_um = 25.0
translation_x_um = 41.0
translation_y_um = -17.0


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    original = c << gf.components.L(
        width=arm_width_um, size=(size_x_um, size_y_um), layer=layer
    )
    original.move((-translation_x_um / 2, -translation_y_um / 2))
    ref = c << gf.components.L(
        width=arm_width_um, size=(size_x_um, size_y_um), layer=layer
    )
    ref.move((translation_x_um / 2, translation_y_um / 2))

    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
