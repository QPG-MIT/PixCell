import json
from pathlib import Path

import gdsfactory as gf

layer = (1, 0)
block_length_um = 35.34
block_height_um = 12.54
triangle_x_um = 20.52
triangle_y_um = 29.64
shared_y_um = -11.4
horizontal_gap_um = 17.1


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    block = c << gf.components.rectangle(
        size=(block_length_um, block_height_um),
        layer=layer,
        centered=False,
    )
    wedge = c << gf.components.triangle(
        x=triangle_x_um, y=triangle_y_um, layer=layer
    )
    block.move((-block_length_um - horizontal_gap_um / 2, shared_y_um))
    wedge.move((horizontal_gap_um / 2 - wedge.xmin, shared_y_um - wedge.ymin))

    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
