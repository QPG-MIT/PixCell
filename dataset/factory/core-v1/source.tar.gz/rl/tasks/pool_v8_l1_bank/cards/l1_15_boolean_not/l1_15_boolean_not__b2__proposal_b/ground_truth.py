import json
from pathlib import Path

import gdsfactory as gf

cutter_dx_um = 21.66
cutter_dy_um = 13.68
layer = (1, 0)


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    outer = gf.components.rectangle(
        size=(42.0, 28.0), layer=layer, centered=True
    )
    cutter_parent = gf.Component()
    cutter = cutter_parent << gf.components.circle(radius=10.0, layer=layer)
    cutter.move((cutter_dx_um, cutter_dy_um))
    result = c << gf.boolean(
        A=outer, B=cutter_parent, operation="not", layer=layer
    )
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
