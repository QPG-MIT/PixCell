import json
from pathlib import Path

import gdsfactory as gf

layer = (1, 0)
ring_radius_um = 16.0
ring_width_um = 4.0
disk_radius_um = 5.0


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    ring = c << gf.components.ring(
        radius=ring_radius_um, width=ring_width_um, layer=layer
    )
    disk = c << gf.components.circle(radius=disk_radius_um, layer=layer)
    inner_radius_um = ring_radius_um - ring_width_um / 2
    disk.move((inner_radius_um - disk_radius_um, 0))

    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
