import json
from pathlib import Path

import gdsfactory as gf

count = 8
orbit_um = 27.36
layer = (1, 0)


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    import math
    for index in range(count):
        angle_deg = index * 360 / count
        angle_rad = math.radians(angle_deg)
        tooth = c << gf.components.triangle(
            x=8.0, y=11.0, layer=layer
        )
        tooth.rotate(angle_deg - 90)
        tooth.move((
            orbit_um * math.cos(angle_rad),
            orbit_um * math.sin(angle_rad),
        ))
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
