import json
from pathlib import Path

import gdsfactory as gf

layer = (1, 0)
arm_width_um = 6.0
size_x_um = 21.0
size_y_um = 29.0
translation_x_um = 34.0
translation_y_um = 14.0


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    original = c << gf.components.L(
        width=arm_width_um, size=(size_x_um, size_y_um), layer=layer
    )
    original.move((-translation_x_um / 2, -translation_y_um / 2))
    ref = c << gf.components.L(
        width=arm_width_um, size=(size_x_um, size_y_um), layer=layer
    )
    ref.move((translation_x_um / 2, translation_y_um / 2))

    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
