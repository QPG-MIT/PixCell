import json
from pathlib import Path

import gdsfactory as gf

layer = (1, 0)
triangle_x_um = 18.0
triangle_y_um = 27.0
separation_x_um = 40.0
vertical_offset_um = 7.0
pose_rotation_deg = 45.0


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    pose_scene = gf.Component()
    original = pose_scene << gf.components.triangle(
        x=triangle_x_um, y=triangle_y_um, layer=layer
    )
    original.move((-separation_x_um / 2, vertical_offset_um))
    ref = pose_scene << gf.components.triangle(
        x=triangle_x_um, y=triangle_y_um, layer=layer
    )
    ref.mirror()
    ref.move((separation_x_um / 2, -vertical_offset_um))
    pose_ref = c << pose_scene
    pose_ref.rotate(pose_rotation_deg)
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
