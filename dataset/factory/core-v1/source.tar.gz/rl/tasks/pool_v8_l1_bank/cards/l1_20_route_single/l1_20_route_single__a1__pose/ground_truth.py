import json
from pathlib import Path

import gdsfactory as gf

dx_um = 70.0
dy_um = 0.0
end_rotation_deg = 180.0
radius_um = 7.0
detour_x1_um = 28.0
detour_y_um = 22.0
detour_x2_um = 54.0
layer = (1, 0)
pose_rotation_deg = 90.0


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    pose_scene = gf.Component()
    xs = gf.cross_section.cross_section(
        width=4.0, layer=layer, radius=radius_um, radius_min=2.0
    )
    start = pose_scene << gf.components.straight(length=12.0, cross_section=xs)
    end = pose_scene << gf.components.straight(length=12.0, cross_section=xs)
    end.rotate(end_rotation_deg)
    end.move((dx_um, dy_um))
    gf.routing.route_single(
        pose_scene, start.ports["o2"], end.ports["o2"],
        cross_section=xs, radius=radius_um,

        steps=[
            {"x": detour_x1_um},
            {"y": detour_y_um},
            {"x": detour_x2_um},
            {"y": 0.0},
        ],

    )
    pose_scene.add_port("o1", port=start.ports["o1"])
    pose_scene.add_port("o2", port=end.ports["o1"])
    pose_ref = c << pose_scene
    pose_ref.rotate(pose_rotation_deg)
    c.add_port("o1", port=pose_ref.ports["o1"])
    c.add_port("o2", port=pose_ref.ports["o2"])
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
