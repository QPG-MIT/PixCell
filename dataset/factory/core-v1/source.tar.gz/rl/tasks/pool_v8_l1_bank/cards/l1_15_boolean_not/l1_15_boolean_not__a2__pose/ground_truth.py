import json
from pathlib import Path

import gdsfactory as gf

hole_x_um = 13.0
hole_y_um = 8.0
layer = (1, 0)
pose_rotation_deg = 45.0


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    pose_scene = gf.Component()
    outer = gf.components.rectangle(
        size=(42.0, 30.0), layer=layer, centered=True
    )
    inner = gf.components.ellipse(
        radii=(hole_x_um, hole_y_um), layer=layer
    )
    result = pose_scene << gf.boolean(
        A=outer, B=inner, operation="not", layer=layer
    )
    pose_ref = c << pose_scene
    pose_ref.rotate(pose_rotation_deg)
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
