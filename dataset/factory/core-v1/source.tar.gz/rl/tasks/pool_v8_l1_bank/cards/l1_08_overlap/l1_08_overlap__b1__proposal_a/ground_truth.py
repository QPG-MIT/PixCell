import json
from pathlib import Path

import gdsfactory as gf

layer = (1, 0)
arm_width_um = 7.0
size_x_um = 29.0
size_y_um = 31.0
ellipse_radius_x_um = 15.0
ellipse_radius_y_um = 9.0
offset_x_um = 8.0
offset_y_um = 3.0


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    elbow = c << gf.components.L(
        width=arm_width_um, size=(size_x_um, size_y_um), layer=layer
    )
    ellipse = c << gf.components.ellipse(
        radii=(ellipse_radius_x_um, ellipse_radius_y_um), layer=layer
    )
    ellipse.move((offset_x_um, offset_y_um))

    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
