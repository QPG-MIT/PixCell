import json
from pathlib import Path

import gdsfactory as gf

count = 8
pitch_um = 13.0
peak_index = 5
layer = (1, 0)


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    for index in range(count):
        distance = abs(index - peak_index)
        radius_y_um = max(3.0, 9.0 - distance * 1.2)
        item = c << gf.components.ellipse(
            radii=(4.0, radius_y_um), layer=layer
        )
        item.move((index * pitch_um, 0))
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
