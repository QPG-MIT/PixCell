import json
from pathlib import Path

import gdsfactory as gf

layer = (1, 0)
default_bend_radius_um = 9.12
minimum_bend_radius_um = 1.14
bus_length_um = 63.84
width_um = 4.56
ring_radius_um = 15.96
gap_um = 5.7


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    xs = gf.cross_section.cross_section(
        width=width_um,
        layer=layer,
        radius=default_bend_radius_um,
        radius_min=minimum_bend_radius_um,
    )
    bus = c << gf.components.straight(
        length=bus_length_um, cross_section=xs
    )
    ring = c << gf.components.ring(
        radius=ring_radius_um, width=width_um, layer=layer
    )
    ring.move((bus_length_um / 2, bus.ymax + gap_um - ring.ymin))

    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
