import json
from pathlib import Path

import gdsfactory as gf

layer = (1, 0)
arm_width_um = 4.5
size_x_um = 15.0
size_y_um = 21.0
angle_step_deg = 48.0
orbit_um = 23.0
pose_rotation_deg = 45.0


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    pose_scene = gf.Component()
    import math
    for index in range(3):
        angle_deg = (index - 1) * angle_step_deg
        angle_rad = math.radians(angle_deg)
        ref = pose_scene << gf.components.L(
            width=arm_width_um,
            size=(size_x_um, size_y_um),
            layer=layer,
        )
        ref.rotate(angle_deg)
        ref.move((
            orbit_um * math.cos(angle_rad),
            orbit_um * math.sin(angle_rad),
        ))
    pose_ref = c << pose_scene
    pose_ref.rotate(pose_rotation_deg)
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
