import json
from pathlib import Path

import gdsfactory as gf

layer = (1, 0)
bar_length_um = 26.22
bar_width_um = 6.84
disk_radius_um = 4.56
cross_length_um = 11.4
cross_width_um = 3.42
separation_x_um = 57.0


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    unit = gf.Component()
    bar = unit << gf.components.rectangle(
        size=(bar_length_um, bar_width_um), layer=layer, centered=True
    )
    disk = unit << gf.components.circle(radius=disk_radius_um, layer=layer)
    disk.move((7.0, 8.0))
    cross = unit << gf.components.cross(
        length=cross_length_um, width=cross_width_um, layer=layer
    )
    cross.move((-8.0, -7.0))
    original = c << unit
    original.move((-separation_x_um / 2, 0))
    ref = c << unit
    ref.mirror()
    ref.move((separation_x_um / 2, 0))

    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
