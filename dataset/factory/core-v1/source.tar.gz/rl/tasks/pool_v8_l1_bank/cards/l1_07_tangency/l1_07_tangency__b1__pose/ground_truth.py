import json
from pathlib import Path

import gdsfactory as gf

layer = (1, 0)
bar_length_um = 36.0
bar_height_um = 12.0
disk_radius_um = 9.0
pose_rotation_deg = 135.0


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    pose_scene = gf.Component()
    bar = pose_scene << gf.components.rectangle(
        size=(bar_length_um, bar_height_um), layer=layer, centered=True
    )
    disk = pose_scene << gf.components.circle(radius=disk_radius_um, layer=layer)
    disk.move((bar_length_um / 2 + disk_radius_um, 0))
    pose_ref = c << pose_scene
    pose_ref.rotate(pose_rotation_deg)
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
