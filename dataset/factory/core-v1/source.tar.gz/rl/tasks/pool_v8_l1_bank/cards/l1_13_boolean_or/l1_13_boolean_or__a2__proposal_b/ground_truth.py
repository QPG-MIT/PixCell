import json
from pathlib import Path

import gdsfactory as gf

lobe_offset_um = 15.96
bridge_width_um = 6.84
layer = (1, 0)


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    lobes = gf.Component()
    left = lobes << gf.components.circle(radius=12.0, layer=layer)
    right = lobes << gf.components.circle(radius=12.0, layer=layer)
    left.move((-lobe_offset_um, 0))
    right.move((lobe_offset_um, 0))
    bridge = gf.components.rectangle(
        size=(2 * lobe_offset_um, bridge_width_um),
        layer=layer, centered=True
    )
    result = c << gf.boolean(
        A=lobes, B=bridge, operation="or", layer=layer
    )
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
