import json
from pathlib import Path

import gdsfactory as gf

layer = (1, 0)
narrow_width_um = 4.0
wide_width_um = 12.0
taper_length_um = 28.0
tail_length_um = 26.0
default_bend_radius_um = 10.0
minimum_bend_radius_um = 2.0
pose_rotation_deg = 135.0


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    pose_scene = gf.Component()
    taper = pose_scene << gf.components.taper(
        length=taper_length_um,
        width1=narrow_width_um,
        width2=wide_width_um,
        layer=layer,
        with_bbox=False,
    )
    xs = gf.cross_section.cross_section(
        width=wide_width_um,
        layer=layer,
        radius=default_bend_radius_um,
        radius_min=minimum_bend_radius_um,
    )
    ref = pose_scene << gf.components.straight(
        length=tail_length_um, cross_section=xs
    )
    ref.connect("o1", taper.ports["o2"])
    pose_scene.add_port("o1", port=taper.ports["o1"])
    pose_scene.add_port("o2", port=ref.ports["o2"])
    pose_ref = c << pose_scene
    pose_ref.rotate(pose_rotation_deg)
    c.add_port("o1", port=pose_ref.ports["o1"])
    c.add_port("o2", port=pose_ref.ports["o2"])
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
