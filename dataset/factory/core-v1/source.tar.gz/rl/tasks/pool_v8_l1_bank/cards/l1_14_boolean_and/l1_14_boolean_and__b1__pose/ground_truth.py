import json
from pathlib import Path

import gdsfactory as gf

angle_deg = 31.0
layer = (1, 0)
pose_rotation_deg = 135.0


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    pose_scene = gf.Component()
    first_parent = gf.Component()
    first = first_parent << gf.components.rectangle(
        size=(43.0, 14.0), layer=layer, centered=True
    )
    first.rotate(angle_deg)
    second_parent = gf.Component()
    second = second_parent << gf.components.rectangle(
        size=(43.0, 14.0), layer=layer, centered=True
    )
    second.rotate(-angle_deg)
    result = pose_scene << gf.boolean(
        A=first_parent, B=second_parent,
        operation="and", layer=layer
    )
    pose_ref = c << pose_scene
    pose_ref.rotate(pose_rotation_deg)
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
