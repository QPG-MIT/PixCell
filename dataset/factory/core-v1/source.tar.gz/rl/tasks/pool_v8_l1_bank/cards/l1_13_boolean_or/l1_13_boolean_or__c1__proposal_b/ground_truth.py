import json
from pathlib import Path

import gdsfactory as gf

separation_um = 14.82
layer = (1, 0)


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    pair = gf.Component()
    left = pair << gf.components.circle(radius=11.0, layer=layer)
    middle = pair << gf.components.circle(radius=11.0, layer=layer)
    left.move((-separation_um, 0))
    middle.move((0, 0))
    third_parent = gf.Component()
    third = third_parent << gf.components.circle(radius=11.0, layer=layer)
    third.move((separation_um, 0))
    result = c << gf.boolean(
        A=pair, B=third_parent, operation="or", layer=layer
    )
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
