import json
from pathlib import Path

import gdsfactory as gf

layer = (1, 0)
outer_radius_um = 21.66
outer_width_um = 3.42
inner_radius_um = 11.97
inner_width_um = 3.42
center_x_um = -1.14
center_y_um = 2.28


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    outer = c << gf.components.ring(
        radius=outer_radius_um, width=outer_width_um, layer=layer
    )
    inner = c << gf.components.ring(
        radius=inner_radius_um, width=inner_width_um, layer=layer
    )
    outer.move((center_x_um, center_y_um))
    inner.move((center_x_um, center_y_um))

    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
