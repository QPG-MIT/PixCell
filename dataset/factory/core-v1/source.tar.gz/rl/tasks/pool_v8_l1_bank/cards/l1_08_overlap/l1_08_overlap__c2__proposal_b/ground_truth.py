import json
from pathlib import Path

import gdsfactory as gf

layer = (1, 0)
disk_radius_um = 13.68
center_offset_um = 10.26


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    left = c << gf.components.circle(radius=disk_radius_um, layer=layer)
    right = c << gf.components.circle(radius=disk_radius_um, layer=layer)
    top = c << gf.components.circle(radius=disk_radius_um, layer=layer)
    left.move((-center_offset_um, 0))
    right.move((center_offset_um, 0))
    top.move((0, center_offset_um))

    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
