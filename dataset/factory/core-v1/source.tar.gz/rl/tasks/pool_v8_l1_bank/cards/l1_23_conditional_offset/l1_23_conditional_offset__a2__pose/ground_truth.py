import json
from pathlib import Path

import gdsfactory as gf

count = 9
pitch_um = 11.0
offset_um = 8.0
layer = (1, 0)
pose_rotation_deg = 45.0


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    pose_scene = gf.Component()
    for index in range(count):
        lane = index % 3
        y_um = (lane - 1) * offset_um
        item = pose_scene << gf.components.circle(radius=3.6, layer=layer)
        item.move((index * pitch_um, y_um))
    pose_ref = c << pose_scene
    pose_ref.rotate(pose_rotation_deg)
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
