import json
from pathlib import Path

import gdsfactory as gf

layer = (1, 0)
block_length_um = 26.0
block_height_um = 14.0
triangle_x_um = 21.0
triangle_y_um = 23.0
shared_y_um = -12.0
horizontal_gap_um = 12.0
pose_rotation_deg = 135.0


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    pose_scene = gf.Component()
    block = pose_scene << gf.components.rectangle(
        size=(block_length_um, block_height_um),
        layer=layer,
        centered=False,
    )
    wedge = pose_scene << gf.components.triangle(
        x=triangle_x_um, y=triangle_y_um, layer=layer
    )
    block.move((-block_length_um - horizontal_gap_um / 2, shared_y_um))
    wedge.move((horizontal_gap_um / 2 - wedge.xmin, shared_y_um - wedge.ymin))
    pose_ref = c << pose_scene
    pose_ref.rotate(pose_rotation_deg)
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
