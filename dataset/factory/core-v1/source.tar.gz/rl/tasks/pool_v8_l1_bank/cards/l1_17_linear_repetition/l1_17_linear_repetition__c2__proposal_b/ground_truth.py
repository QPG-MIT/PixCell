import json
from pathlib import Path

import gdsfactory as gf

count = 6
pitch_um = 17.1
layer = (1, 0)


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    for index in range(count):
        item = c << gf.components.triangle(x=7.0, y=11.0, layer=layer)
        item.move((index * pitch_um, 0))
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
