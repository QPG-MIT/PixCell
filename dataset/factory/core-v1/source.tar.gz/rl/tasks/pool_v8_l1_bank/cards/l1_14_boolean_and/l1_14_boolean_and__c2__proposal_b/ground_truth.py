import json
from pathlib import Path

import gdsfactory as gf

bar_dx_um = 5.7
bar_angle_deg = 12.0
layer = (1, 0)


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    ring = gf.components.ring(radius=16.0, width=4.0, layer=layer)
    bar_parent = gf.Component()
    bar = bar_parent << gf.components.rectangle(
        size=(11.0, 41.0), layer=layer, centered=True
    )
    bar.rotate(bar_angle_deg)
    bar.move((bar_dx_um, 0))
    result = c << gf.boolean(
        A=ring, B=bar_parent, operation="and", layer=layer
    )
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
