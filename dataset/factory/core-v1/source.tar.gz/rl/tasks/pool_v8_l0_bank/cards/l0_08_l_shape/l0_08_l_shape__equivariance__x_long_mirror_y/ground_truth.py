import json
from pathlib import Path

import gdsfactory as gf

arm_width_um = 6.0
size_x_um = 38.0
size_y_um = 23.0
layer = (1, 0)


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    ref = c << gf.components.L(
        width=arm_width_um, size=(size_x_um, size_y_um), layer=layer
    )
    ref.mirror_y()
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
