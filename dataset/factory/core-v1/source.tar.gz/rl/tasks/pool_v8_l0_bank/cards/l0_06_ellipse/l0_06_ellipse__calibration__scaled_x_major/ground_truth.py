import json
from pathlib import Path

import gdsfactory as gf

radius_x_um = 22.5
radius_y_um = 17.25
layer = (1, 0)


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    ref = c << gf.components.ellipse(
        radii=(radius_x_um, radius_y_um), layer=layer
    )
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
