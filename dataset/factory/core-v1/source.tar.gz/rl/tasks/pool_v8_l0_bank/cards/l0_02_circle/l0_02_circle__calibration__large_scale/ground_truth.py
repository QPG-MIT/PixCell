import json
from pathlib import Path

import gdsfactory as gf

radius_um = 18.0
layer = (1, 0)


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    ref = c << gf.components.circle(radius=radius_um, layer=layer)
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
