import json
from pathlib import Path

import gdsfactory as gf

base_um = 28.0
height_um = 22.0
layer = (1, 0)
presentation_rotation_deg = 270.0


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    ref = c << gf.components.triangle(x=base_um, y=height_um, layer=layer)
    ref.rotate(presentation_rotation_deg)
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
