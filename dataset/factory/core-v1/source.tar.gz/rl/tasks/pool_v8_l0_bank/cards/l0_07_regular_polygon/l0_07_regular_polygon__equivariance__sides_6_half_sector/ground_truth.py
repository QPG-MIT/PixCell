import json
from pathlib import Path

import gdsfactory as gf

sides = 6
side_length_um = 12.0
layer = (1, 0)
presentation_rotation_deg = 30.0


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    ref = c << gf.components.regular_polygon(
        sides=sides, side_length=side_length_um, layer=layer
    )
    ref.rotate(presentation_rotation_deg)
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
