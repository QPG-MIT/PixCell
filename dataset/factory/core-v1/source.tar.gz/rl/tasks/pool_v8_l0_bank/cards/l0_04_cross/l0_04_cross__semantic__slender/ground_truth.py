import json
from pathlib import Path

import gdsfactory as gf

cross_length_um = 28.0
cross_width_um = 3.5
layer = (1, 0)


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    ref = c << gf.components.cross(
        length=cross_length_um, width=cross_width_um, layer=layer
    )
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
