import json
from pathlib import Path

import gdsfactory as gf

length_um = 42.0
waveguide_width_um = 4.0
default_bend_radius_um = 10.0
minimum_bend_radius_um = 2.0
layer = (1, 0)


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    xs = gf.cross_section.cross_section(
        width=waveguide_width_um, layer=layer,
        radius=default_bend_radius_um, radius_min=minimum_bend_radius_um
    )
    ref = c << gf.components.straight(length=length_um, cross_section=xs)
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
