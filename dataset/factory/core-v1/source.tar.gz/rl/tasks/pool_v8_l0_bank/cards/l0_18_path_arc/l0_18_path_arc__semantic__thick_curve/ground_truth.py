import json
from pathlib import Path

import gdsfactory as gf

arc_radius_um = 14.0
arc_angle_deg = 120.0
path_width_um = 7.0
minimum_bend_radius_um = 1.0
layer = (1, 0)


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    path = gf.path.arc(radius=arc_radius_um, angle=arc_angle_deg)
    xs = gf.cross_section.cross_section(
        width=path_width_um, layer=layer,
        radius=arc_radius_um, radius_min=minimum_bend_radius_um
    )
    ref = c << gf.path.extrude(p=path, cross_section=xs)
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
