import json
from pathlib import Path

import gdsfactory as gf

length_um = 36.0
input_width_um = 4.0
output_width_um = 12.0
layer = (1, 0)


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    ref = c << gf.components.taper(
        length=length_um, width1=input_width_um, width2=output_width_um,
        layer=layer, with_bbox=False
    )
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
