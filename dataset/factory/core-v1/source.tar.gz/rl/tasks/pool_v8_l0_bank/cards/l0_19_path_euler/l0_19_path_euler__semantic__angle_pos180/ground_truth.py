import json
from pathlib import Path

import gdsfactory as gf

euler_radius_um = 16.0
euler_angle_deg = 180.0
euler_fraction = 0.5
path_width_um = 4.0
minimum_bend_radius_um = 1.0
layer = (1, 0)


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    path = gf.path.euler(
        radius=euler_radius_um, angle=euler_angle_deg,
        p=euler_fraction, use_eff=True
    )
    xs = gf.cross_section.cross_section(
        width=path_width_um, layer=layer,
        radius=euler_radius_um, radius_min=minimum_bend_radius_um
    )
    ref = c << gf.path.extrude(p=path, cross_section=xs)
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
