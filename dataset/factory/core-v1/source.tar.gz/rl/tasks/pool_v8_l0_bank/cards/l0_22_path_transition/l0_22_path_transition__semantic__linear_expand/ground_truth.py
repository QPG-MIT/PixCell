import json
from pathlib import Path

import gdsfactory as gf

transition_length_um = 40.0
default_bend_radius_um = 8.0
minimum_bend_radius_um = 1.0
layer = (1, 0)
start_width_um = 3.0
end_width_um = 14.0
transition_profile = 'linear'
transition_npoints = 101


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    path = gf.path.straight(
        length=transition_length_um, npoints=transition_npoints
    )
    start_xs = gf.cross_section.cross_section(
        width=start_width_um, layer=layer,
        radius=default_bend_radius_um, radius_min=minimum_bend_radius_um
    )
    end_xs = gf.cross_section.cross_section(
        width=end_width_um, layer=layer,
        radius=default_bend_radius_um, radius_min=minimum_bend_radius_um
    )
    profile = gf.path.transition(
        cross_section1=start_xs, cross_section2=end_xs,
        width_type=transition_profile
    )
    ref = c << gf.path.extrude_transition(p=path, transition=profile)
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
