import json
from pathlib import Path

import gdsfactory as gf

minimum_spiral_radius_um = 8.0
separation_um = 4.5
number_of_loops = 2.0
npoints = 280
path_width_um = 3.5
default_bend_radius_um = 8.0
minimum_bend_radius_um = 1.0
layer = (1, 0)


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    path = gf.path.spiral_archimedean(
        min_bend_radius=minimum_spiral_radius_um,
        separation=separation_um, number_of_loops=number_of_loops,
        npoints=npoints
    )
    xs = gf.cross_section.cross_section(
        width=path_width_um, layer=layer,
        radius=default_bend_radius_um, radius_min=minimum_bend_radius_um
    )
    ref = c << gf.path.extrude(p=path, cross_section=xs)
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
