import json
from pathlib import Path

import gdsfactory as gf

bend_radius_um = 15.0
bend_angle_deg = 135.0
euler_fraction = 0.5
waveguide_width_um = 4.0
minimum_bend_radius_um = 2.0
layer = (1, 0)


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    xs = gf.cross_section.cross_section(
        width=waveguide_width_um, layer=layer,
        radius=bend_radius_um, radius_min=minimum_bend_radius_um
    )
    ref = c << gf.components.bend_euler(
        radius=bend_radius_um, angle=bend_angle_deg,
        p=euler_fraction, cross_section=xs
    )
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
