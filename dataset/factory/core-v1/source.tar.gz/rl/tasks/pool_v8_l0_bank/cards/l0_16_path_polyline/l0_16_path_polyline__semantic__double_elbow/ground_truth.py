import json
from pathlib import Path

import gdsfactory as gf

centerline_points_um = ((0.0, 0.0), (12.0, 0.0), (12.0, 12.0), (28.0, 12.0), (28.0, -4.0), (44.0, -4.0))
path_width_um = 4.0
default_bend_radius_um = 8.0
minimum_bend_radius_um = 1.0
layer = (1, 0)


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    path = gf.Path(centerline_points_um)
    xs = gf.cross_section.cross_section(
        width=path_width_um, layer=layer,
        radius=default_bend_radius_um, radius_min=minimum_bend_radius_um
    )
    ref = c << gf.path.extrude(p=path, cross_section=xs)
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
