import json
from pathlib import Path

import gdsfactory as gf

waypoints_um = ((0.0, 0.0), (15.0, 0.0), (24.0, 11.0), (43.0, 11.0), (57.0, 23.0))
path_bend_radius_um = 3.5
path_width_um = 4.0
default_bend_radius_um = 8.0
minimum_bend_radius_um = 1.0
layer = (1, 0)


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    path = gf.path.smooth(waypoints_um, radius=path_bend_radius_um)
    xs = gf.cross_section.cross_section(
        width=path_width_um, layer=layer,
        radius=default_bend_radius_um, radius_min=minimum_bend_radius_um
    )
    ref = c << gf.path.extrude(p=path, cross_section=xs)
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
