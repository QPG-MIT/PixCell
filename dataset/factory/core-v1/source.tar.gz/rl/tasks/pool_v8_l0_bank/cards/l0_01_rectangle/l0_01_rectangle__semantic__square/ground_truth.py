import json
from pathlib import Path

import gdsfactory as gf

length_um = 22.0
width_um = 22.0
layer = (1, 0)


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    ref = c << gf.components.rectangle(
        size=(length_um, width_um), layer=layer, centered=True
    )
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
