import json
from pathlib import Path

import gdsfactory as gf

control_points_um = ((0.0, 0.0), (8.0, 0.0), (17.0, 15.0), (29.0, 5.0), (44.0, 19.0), (56.0, 19.0))
waveguide_width_um = 4.0
default_bend_radius_um = 8.0
minimum_bend_radius_um = 1.0
layer = (1, 0)


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    xs = gf.cross_section.cross_section(
        width=waveguide_width_um, layer=layer,
        radius=default_bend_radius_um, radius_min=minimum_bend_radius_um
    )
    ref = c << gf.components.bezier(
        control_points=control_points_um, cross_section=xs,
        allow_min_radius_violation=True
    )
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
