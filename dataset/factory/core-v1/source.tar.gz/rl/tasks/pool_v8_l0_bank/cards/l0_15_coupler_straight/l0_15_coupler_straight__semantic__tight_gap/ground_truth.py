import json
from pathlib import Path

import gdsfactory as gf

coupling_length_um = 40.0
waveguide_width_um = 3.5
gap_um = 1.5
default_bend_radius_um = 10.0
minimum_bend_radius_um = 2.0
layer = (1, 0)


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    xs = gf.cross_section.cross_section(
        width=waveguide_width_um, layer=layer,
        radius=default_bend_radius_um, radius_min=minimum_bend_radius_um
    )
    ref = c << gf.components.coupler_straight(
        length=coupling_length_um, gap=gap_um, cross_section=xs
    )
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
