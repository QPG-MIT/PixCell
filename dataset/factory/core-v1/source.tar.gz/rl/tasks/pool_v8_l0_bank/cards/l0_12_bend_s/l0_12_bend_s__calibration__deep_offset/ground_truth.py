import json
from pathlib import Path

import gdsfactory as gf

offset_x_um = 34.0
offset_y_um = 23.0
waveguide_width_um = 4.0
default_bend_radius_um = 8.0
minimum_bend_radius_um = 1.0
layer = (1, 0)


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    xs = gf.cross_section.cross_section(
        width=waveguide_width_um, layer=layer,
        radius=default_bend_radius_um, radius_min=minimum_bend_radius_um
    )
    ref = c << gf.components.bend_s(
        size=(offset_x_um, offset_y_um), cross_section=xs
    )
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
