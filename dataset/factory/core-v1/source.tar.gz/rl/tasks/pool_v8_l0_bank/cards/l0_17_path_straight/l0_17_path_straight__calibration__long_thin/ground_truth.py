import json
from pathlib import Path

import gdsfactory as gf

path_length_um = 80.0
path_width_um = 3.0
default_bend_radius_um = 8.0
minimum_bend_radius_um = 1.0
layer = (1, 0)


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    path = gf.path.straight(length=path_length_um)
    xs = gf.cross_section.cross_section(
        width=path_width_um, layer=layer,
        radius=default_bend_radius_um, radius_min=minimum_bend_radius_um
    )
    ref = c << gf.path.extrude(p=path, cross_section=xs)
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
