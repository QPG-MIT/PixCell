import json
from pathlib import Path

import gdsfactory as gf

anchor_x_um = 24.0
vertical_pitch_um = 24.0
layer = (1, 0)


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    lower = c << gf.components.ellipse(
        radii=(15.0, 6.0), layer=layer
    )
    lower.rotate(18.0)
    lower.movex(anchor_x_um - lower.xmax)
    lower.movey(-vertical_pitch_um)
    middle = c << gf.components.ellipse(
        radii=(15.0, 6.0), layer=layer
    )
    middle.rotate(47.0)
    middle.movex(anchor_x_um - middle.xmax)
    upper = c << gf.components.ellipse(
        radii=(15.0, 6.0), layer=layer
    )
    upper.rotate(76.0)
    upper.movex(anchor_x_um - upper.xmax)
    upper.movey(vertical_pitch_um)
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
