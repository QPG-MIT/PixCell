import json
from pathlib import Path

import gdsfactory as gf

rows = 4
columns = 5
pitch_x_um = 15.0
pitch_y_um = 14.0
layer = (1, 0)


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    for row in range(rows):
        row_shift_um = pitch_x_um / 2 if row % 2 else 0.0
        for column in range(columns):
            item = c << gf.components.circle(radius=4.0, layer=layer)
            item.move((
                column * pitch_x_um + row_shift_um,
                row * pitch_y_um,
            ))
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
