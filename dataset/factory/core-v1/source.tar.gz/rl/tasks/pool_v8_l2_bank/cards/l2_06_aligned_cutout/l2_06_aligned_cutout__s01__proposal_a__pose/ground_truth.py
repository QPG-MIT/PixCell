import json
from pathlib import Path

import gdsfactory as gf

host_x_um = 56.0
host_y_um = 36.0
layer = (1, 0)
pose_rotation_deg = 90.0


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    pose_scene = gf.Component()
    host = gf.components.rectangle(
        size=(host_x_um, host_y_um), layer=layer, centered=True
    )
    cutter = gf.components.ellipse(radii=(18.0, 9.0), layer=layer)
    result = pose_scene << gf.boolean(
        A=host, B=cutter, operation="not", layer=layer
    )
    pose_ref = c << pose_scene
    pose_ref.rotate(pose_rotation_deg)
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
