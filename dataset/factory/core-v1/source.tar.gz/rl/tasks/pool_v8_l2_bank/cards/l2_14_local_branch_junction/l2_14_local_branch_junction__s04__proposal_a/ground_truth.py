import json
from pathlib import Path

import gdsfactory as gf

width_um = 6.0
trunk_length_um = 24.0
arm_length_um = 48.0
upper_angle_deg = 24.0
lower_angle_deg = -36.0
layer = (1, 0)


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    xs = gf.cross_section.cross_section(width=width_um, layer=layer)
    trunk = c << gf.components.straight(
        length=trunk_length_um, cross_section=xs
    )
    upper = c << gf.components.straight(
        length=arm_length_um, cross_section=xs
    )
    upper.connect("o1", trunk.ports["o2"])
    upper.rotate(
        upper_angle_deg, center=trunk.ports["o2"].center
    )
    lower = c << gf.components.straight(
        length=arm_length_um, cross_section=xs
    )
    lower.connect("o1", trunk.ports["o2"])
    lower.rotate(
        lower_angle_deg, center=trunk.ports["o2"].center
    )
    c.add_port("o1", port=trunk.ports["o1"])
    c.add_port("o2", port=upper.ports["o2"])
    c.add_port("o3", port=lower.ports["o2"])
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
