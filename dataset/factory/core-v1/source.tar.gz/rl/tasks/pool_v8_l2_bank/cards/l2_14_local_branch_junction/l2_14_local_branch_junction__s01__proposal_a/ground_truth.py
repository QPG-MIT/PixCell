import json
from pathlib import Path

import gdsfactory as gf

width_um = 6.0
branch_offset_um = 20.0
layer = (1, 0)


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    xs = gf.cross_section.cross_section(width=width_um, layer=layer)
    trunk = c << gf.components.straight(length=25.0, cross_section=xs)
    c.add_port("o1", port=trunk.ports["o1"])
    arm_cell = gf.components.bend_s(
        size=(42.0, branch_offset_um), cross_section=xs
    )
    upper = c << arm_cell
    upper.connect("o1", trunk.ports["o2"])
    lower = c << arm_cell
    lower.connect("o1", trunk.ports["o2"], mirror=True)
    c.add_port("o2", port=upper.ports["o2"])
    c.add_port("o3", port=lower.ports["o2"])
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
