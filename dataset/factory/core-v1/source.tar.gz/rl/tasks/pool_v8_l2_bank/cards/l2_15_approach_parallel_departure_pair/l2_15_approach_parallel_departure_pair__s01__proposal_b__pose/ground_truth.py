import json
from pathlib import Path

import gdsfactory as gf

width_um = 5.4
outer_pitch_um = 31.0
inner_pitch_um = 11.0
layer = (1, 0)
pose_rotation_deg = 90.0


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    pose_scene = gf.Component()
    xs = gf.cross_section.cross_section(width=width_um, layer=layer)
    shift_um = (outer_pitch_um - inner_pitch_um) / 2
    rail_cell = gf.Component()
    approach = rail_cell << gf.components.bend_s(
        size=(29.0, -shift_um), cross_section=xs
    )
    interaction = rail_cell << gf.components.straight(
        length=43.0, cross_section=xs
    )
    interaction.connect("o1", approach.ports["o2"])
    depart = rail_cell << gf.components.bend_s(
        size=(29.0, shift_um), cross_section=xs
    )
    depart.connect("o1", interaction.ports["o2"])
    rail_cell.add_port("o1", port=approach.ports["o1"])
    rail_cell.add_port("o2", port=depart.ports["o2"])
    upper = pose_scene << rail_cell
    upper.movey(outer_pitch_um / 2)
    lower = pose_scene << rail_cell
    lower.mirror_y()
    lower.movey(-outer_pitch_um / 2)
    pose_scene.add_port("o1", port=upper.ports["o1"])
    pose_scene.add_port("o2", port=lower.ports["o1"])
    pose_scene.add_port("o3", port=upper.ports["o2"])
    pose_scene.add_port("o4", port=lower.ports["o2"])
    pose_ref = c << pose_scene
    pose_ref.rotate(pose_rotation_deg)
    c.add_port("o1", port=pose_ref.ports["o1"])
    c.add_port("o2", port=pose_ref.ports["o2"])
    c.add_port("o3", port=pose_ref.ports["o3"])
    c.add_port("o4", port=pose_ref.ports["o4"])
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
