import json
from pathlib import Path

import gdsfactory as gf

width_um = 5.0
outer_pitch_um = 33.0
inner_pitch_um = 12.0
approach_length_um = 30.0
window_length_um = 48.0
layer = (1, 0)


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    xs = gf.cross_section.cross_section(width=width_um, layer=layer)
    shift_um = (outer_pitch_um - inner_pitch_um) / 2
    upper = c << gf.components.straight(
        length=2 * approach_length_um + window_length_um,
        cross_section=xs,
    )
    upper.movey(inner_pitch_um / 2)
    approach = c << gf.components.bend_s(
        size=(approach_length_um, shift_um), cross_section=xs
    )
    approach.movey(-outer_pitch_um / 2)
    run = c << gf.components.straight(
        length=window_length_um, cross_section=xs
    )
    run.connect("o1", approach.ports["o2"])
    depart = c << gf.components.bend_s(
        size=(approach_length_um, -shift_um), cross_section=xs
    )
    depart.connect("o1", run.ports["o2"])
    c.add_port("o1", port=upper.ports["o1"])
    c.add_port("o2", port=approach.ports["o1"])
    c.add_port("o3", port=upper.ports["o2"])
    c.add_port("o4", port=depart.ports["o2"])
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
