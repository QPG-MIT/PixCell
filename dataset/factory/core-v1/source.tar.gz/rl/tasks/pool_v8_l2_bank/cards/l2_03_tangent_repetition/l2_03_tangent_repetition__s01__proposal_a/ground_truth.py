import json
from pathlib import Path

import gdsfactory as gf

count = 6
radius_um = 6.0
layer = (1, 0)


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    for index in range(count):
        disk = c << gf.components.circle(radius=radius_um, layer=layer)
        disk.move((index * 2 * radius_um, 0))
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
