import json
from pathlib import Path

import gdsfactory as gf

hole_offset_um = 12.88
layer = (1, 0)


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    first_parent = gf.Component()
    first = first_parent << gf.components.rectangle(
        size=(64.0, 18.0), layer=layer, centered=True
    )
    second_parent = gf.Component()
    second = second_parent << gf.components.rectangle(
        size=(46.0, 16.0), layer=layer, centered=True
    )
    second.rotate(90)
    fused = gf.boolean(
        A=first_parent, B=second_parent, operation="or", layer=layer
    )
    cutters = gf.Component()
    left_hole = cutters << gf.components.circle(
        radius=6.0, layer=layer
    )
    left_hole.move((-hole_offset_um, 0))
    right_hole = cutters << gf.components.circle(
        radius=6.0, layer=layer
    )
    right_hole.move((hole_offset_um, 0))
    result = c << gf.boolean(
        A=fused, B=cutters, operation="not", layer=layer
    )
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
