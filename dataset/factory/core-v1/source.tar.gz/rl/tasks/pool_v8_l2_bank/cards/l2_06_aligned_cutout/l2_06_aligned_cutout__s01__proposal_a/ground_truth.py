import json
from pathlib import Path

import gdsfactory as gf

host_x_um = 56.0
host_y_um = 36.0
layer = (1, 0)


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    host = gf.components.rectangle(
        size=(host_x_um, host_y_um), layer=layer, centered=True
    )
    cutter = gf.components.ellipse(radii=(18.0, 9.0), layer=layer)
    result = c << gf.boolean(
        A=host, B=cutter, operation="not", layer=layer
    )
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
