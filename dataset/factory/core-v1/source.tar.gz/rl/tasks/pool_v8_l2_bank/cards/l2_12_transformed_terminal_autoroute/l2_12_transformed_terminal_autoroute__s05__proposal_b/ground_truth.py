import json
from pathlib import Path

import gdsfactory as gf

width_um = 4.8
terminal_length_um = 18.0
dx_um = 82.0
dy_um = 43.0
radius_um = 8.64
layer = (1, 0)


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    xs = gf.cross_section.cross_section(
        width=width_um, layer=layer, radius_min=radius_um
    )
    start = c << gf.components.straight(
        length=terminal_length_um, cross_section=xs
    )
    end = c << gf.components.straight(
        length=terminal_length_um, cross_section=xs
    )
    end.rotate(90.0)
    end.move((dx_um, dy_um))
    gf.routing.route_single(
        c,
        start.ports["o2"],
        end.ports["o1"],
        cross_section=xs,
        radius=radius_um,
        steps=(
            {"x": 38.0},
            {"y": -27.0},
            {"x": dx_um},
            {"y": dy_um + 27.0},
        ),
    )
    c.add_port("o1", port=start.ports["o1"])
    c.add_port("o2", port=end.ports["o2"])
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
