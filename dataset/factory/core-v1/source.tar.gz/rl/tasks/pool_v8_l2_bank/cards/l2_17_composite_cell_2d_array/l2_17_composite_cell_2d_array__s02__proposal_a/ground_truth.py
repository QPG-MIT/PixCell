import json
from pathlib import Path

import gdsfactory as gf

rows = 3
columns = 3
layer = (1, 0)


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    lobes = gf.Component()
    left = lobes << gf.components.circle(radius=4.5, layer=layer)
    left.move((-7.0, 0))
    right = lobes << gf.components.circle(radius=4.5, layer=layer)
    right.move((7.0, 0))
    bridge = gf.components.rectangle(
        size=(14.0, 5.0), layer=layer, centered=True
    )
    unit = gf.boolean(
        A=lobes, B=bridge, operation="or", layer=layer
    )
    ref = c.add_ref(
        unit, rows=rows, columns=columns,
        row_pitch=18.0, column_pitch=26.0
    )
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
