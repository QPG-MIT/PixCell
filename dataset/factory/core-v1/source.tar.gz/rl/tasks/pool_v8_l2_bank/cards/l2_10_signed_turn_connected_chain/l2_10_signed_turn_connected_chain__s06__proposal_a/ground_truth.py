import json
from pathlib import Path

import gdsfactory as gf

width_um = 5.0
leg_um = 20.0
radius_um = 10.0
layer = (1, 0)


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    xs = gf.cross_section.cross_section(width=width_um, layer=layer)
    path = gf.Path()
    path.append(gf.path.straight(length=leg_um))
    path.append(gf.path.arc(radius=radius_um, angle=105.0))
    path.append(gf.path.straight(length=leg_um))
    path.append(gf.path.arc(radius=radius_um, angle=-66.0))
    path.append(gf.path.straight(length=leg_um + 6.0))
    path.append(gf.path.arc(radius=radius_um, angle=-66.0))
    path.append(gf.path.straight(length=leg_um))
    trace = c << gf.path.extrude(p=path, cross_section=xs)
    left = c << gf.components.straight(length=16.0, cross_section=xs)
    left.connect("o2", trace.ports["o1"])
    right = c << gf.components.straight(length=16.0, cross_section=xs)
    right.connect("o1", trace.ports["o2"])
    c.add_port("o1", port=left.ports["o1"])
    c.add_port("o2", port=right.ports["o2"])
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
