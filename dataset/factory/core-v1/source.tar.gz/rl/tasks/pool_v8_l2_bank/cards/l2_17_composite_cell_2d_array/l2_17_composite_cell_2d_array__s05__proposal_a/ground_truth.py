import json
from pathlib import Path

import gdsfactory as gf

rows = 2
columns = 5
pitch_x_um = 27.0
pitch_y_um = 27.0
lobe_radius_um = 5.0
lobe_orbit_um = 6.0
layer = (1, 0)


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    import math
    lobes = gf.Component()
    for index in range(3):
        angle_rad = math.radians(index * 120.0)
        lobe = lobes << gf.components.circle(
            radius=lobe_radius_um, layer=layer
        )
        lobe.move((
            lobe_orbit_um * math.cos(angle_rad),
            lobe_orbit_um * math.sin(angle_rad),
        ))
    unit = gf.boolean(
        A=lobes,
        B=gf.components.circle(radius=3.8, layer=layer),
        operation="or",
        layer=layer,
    )
    ref = c.add_ref(
        unit,
        rows=rows,
        columns=columns,
        row_pitch=pitch_y_um,
        column_pitch=pitch_x_um,
    )
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
