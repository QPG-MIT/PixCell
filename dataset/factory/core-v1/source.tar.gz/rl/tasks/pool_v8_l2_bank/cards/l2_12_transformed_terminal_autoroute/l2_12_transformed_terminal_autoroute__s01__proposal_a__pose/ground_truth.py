import json
from pathlib import Path

import gdsfactory as gf

width_um = 5.0
dx_um = 72.0
dy_um = 22.0
radius_um = 7.0
layer = (1, 0)
pose_rotation_deg = 90.0


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    pose_scene = gf.Component()
    xs = gf.cross_section.cross_section(
        width=width_um, layer=layer, radius_min=radius_um
    )
    start = pose_scene << gf.components.straight(length=16.0, cross_section=xs)
    end = pose_scene << gf.components.straight(length=16.0, cross_section=xs)
    end.rotate(180.0)
    end.move((dx_um, dy_um))
    gf.routing.route_single(
        pose_scene,
        start.ports["o2"],
        end.ports["o2"],
        cross_section=xs,
        radius=radius_um,
    )
    pose_scene.add_port("o1", port=start.ports["o1"])
    pose_scene.add_port("o2", port=end.ports["o1"])
    pose_ref = c << pose_scene
    pose_ref.rotate(pose_rotation_deg)
    c.add_port("o1", port=pose_ref.ports["o1"])
    c.add_port("o2", port=pose_ref.ports["o2"])
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
