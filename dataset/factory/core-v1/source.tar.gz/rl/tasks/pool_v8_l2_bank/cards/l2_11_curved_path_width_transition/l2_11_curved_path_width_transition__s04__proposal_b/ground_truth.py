import json
from pathlib import Path

import gdsfactory as gf

wide_um = 13.8
narrow_um = 4.0
radius_um = 12.0
layer = (1, 0)


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    path = gf.Path()
    path.append(gf.path.straight(length=16.0))
    path.append(gf.path.arc(radius=radius_um, angle=62.0))
    path.append(gf.path.arc(radius=radius_um, angle=-62.0))
    path.append(gf.path.straight(length=23.0))
    wide_xs = gf.cross_section.cross_section(width=wide_um, layer=layer)
    narrow_xs = gf.cross_section.cross_section(width=narrow_um, layer=layer)
    profile = gf.path.transition(
        cross_section1=wide_xs,
        cross_section2=narrow_xs,
        width_type="sine",
    )
    trace = c << gf.path.extrude_transition(
        p=path, transition=profile
    )
    c.add_port("o1", port=trace.ports["o1"])
    c.add_port("o2", port=trace.ports["o2"])
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
