import json
from pathlib import Path

import gdsfactory as gf

count = 8
radius_um = 5.0
layer = (1, 0)


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    import math
    unit = gf.Component()
    disk = unit << gf.components.circle(
        radius=radius_um, layer=layer
    )
    tab = unit << gf.components.rectangle(
        size=(0.9 * radius_um, 3.0),
        layer=layer,
        centered=True,
    )
    tab.movex(1.3 * radius_um)
    orbit_um = radius_um / math.sin(math.pi / count)
    for index in range(count):
        angle_deg = index * 360.0 / count
        angle_rad = math.radians(angle_deg)
        item = c << unit
        item.rotate(angle_deg)
        item.move((
            orbit_um * math.cos(angle_rad),
            orbit_um * math.sin(angle_rad),
        ))
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
