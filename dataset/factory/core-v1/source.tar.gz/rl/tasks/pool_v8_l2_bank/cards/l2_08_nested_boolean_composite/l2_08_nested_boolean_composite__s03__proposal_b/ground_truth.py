import json
from pathlib import Path

import gdsfactory as gf

tail_offset_um = 5.4
window_offset_um = -8.0
layer = (1, 0)


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    polygon = gf.components.regular_polygon(
        sides=7, side_length=16.0, layer=layer
    )
    tail_parent = gf.Component()
    tail = tail_parent << gf.components.triangle(
        x=34.0, y=24.0, layer=layer
    )
    tail.move((tail_offset_um, -12.0))
    fused = gf.boolean(
        A=polygon, B=tail_parent, operation="or", layer=layer
    )
    cutter_parent = gf.Component()
    cutter = cutter_parent << gf.components.ellipse(
        radii=(8.0, 5.0), layer=layer
    )
    cutter.move((window_offset_um, 0))
    result = c << gf.boolean(
        A=fused, B=cutter_parent, operation="not", layer=layer
    )
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
