import json
from pathlib import Path

import gdsfactory as gf

count = 7
pitch_um = 12.0
gap_um = 12.0
layer = (1, 0)
pose_rotation_deg = 90.0


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    pose_scene = gf.Component()
    bank = gf.Component()
    for index in range(count):
        height_um = 10.0 + index * 4.5
        item = bank << gf.components.rectangle(
            size=(6.0, height_um), layer=layer, centered=True
        )
        item.move((index * pitch_um, height_um / 2))
    upper = pose_scene << bank
    upper.movey(gap_um / 2)
    lower = pose_scene << bank
    lower.mirror_y()
    lower.movey(-gap_um / 2)
    pose_ref = c << pose_scene
    pose_ref.rotate(pose_rotation_deg)
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
