import json
from pathlib import Path

import gdsfactory as gf

ring_radius_um = 17.0
spoke_width_um = 10.8
hole_radius_um = 6.0
layer = (1, 0)


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    ring = gf.components.ring(
        radius=ring_radius_um, width=6.0, layer=layer
    )
    spokes = gf.components.cross(
        length=46.0, width=spoke_width_um, layer=layer
    )
    fused = gf.boolean(
        A=ring, B=spokes, operation="or", layer=layer
    )
    hole_parent = gf.Component()
    hole = hole_parent << gf.components.circle(
        radius=hole_radius_um, layer=layer
    )
    hole.move((8.0, 8.0))
    result = c << gf.boolean(
        A=fused, B=hole_parent, operation="not", layer=layer
    )
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
