import json
from pathlib import Path

import gdsfactory as gf

wide_um = 14.0
narrow_um = 4.0
center_length_um = 30.0
layer = (1, 0)


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    wide_xs = gf.cross_section.cross_section(width=wide_um, layer=layer)
    narrow_xs = gf.cross_section.cross_section(width=narrow_um, layer=layer)
    left = c << gf.components.straight(length=24.0, cross_section=wide_xs)
    center = c << gf.components.straight(
        length=center_length_um, cross_section=narrow_xs
    )
    center.connect(
        "o1", left.ports["o2"], allow_width_mismatch=True
    )
    narrow_tail = c << gf.components.straight(
        length=14.0, cross_section=narrow_xs
    )
    narrow_tail.connect("o1", center.ports["o2"])
    right = c << gf.components.straight(length=24.0, cross_section=wide_xs)
    right.connect(
        "o1", narrow_tail.ports["o2"], allow_width_mismatch=True
    )
    c.add_port("o1", port=left.ports["o1"])
    c.add_port("o2", port=right.ports["o2"])
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
