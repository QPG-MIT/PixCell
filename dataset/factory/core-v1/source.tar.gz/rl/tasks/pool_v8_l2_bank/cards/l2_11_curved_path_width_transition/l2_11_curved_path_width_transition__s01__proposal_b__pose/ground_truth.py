import json
from pathlib import Path

import gdsfactory as gf

width_um = 5.4
wide_um = 14.0
layer = (1, 0)
pose_rotation_deg = 90.0


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    pose_scene = gf.Component()
    path = gf.Path()
    path.append(gf.path.straight(length=18.0))
    path.append(gf.path.arc(radius=13.0, angle=58.0))
    path.append(gf.path.straight(length=28.0))
    narrow_xs = gf.cross_section.cross_section(
        width=width_um, layer=layer
    )
    wide_xs = gf.cross_section.cross_section(
        width=wide_um, layer=layer
    )
    profile = gf.path.transition(
        cross_section1=narrow_xs,
        cross_section2=wide_xs,
        width_type="sine",
    )
    trace = pose_scene << gf.path.extrude_transition(
        p=path, transition=profile
    )
    pose_scene.add_port("o1", port=trace.ports["o1"])
    pose_scene.add_port("o2", port=trace.ports["o2"])
    pose_ref = c << pose_scene
    pose_ref.rotate(pose_rotation_deg)
    c.add_port("o1", port=pose_ref.ports["o1"])
    c.add_port("o2", port=pose_ref.ports["o2"])
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
