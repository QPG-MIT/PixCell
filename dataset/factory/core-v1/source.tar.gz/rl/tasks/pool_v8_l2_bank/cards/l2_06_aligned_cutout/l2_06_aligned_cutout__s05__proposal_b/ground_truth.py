import json
from pathlib import Path

import gdsfactory as gf

host_x_um = 62.0
host_y_um = 36.72
pitch_um = 25.0
layer = (1, 0)


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    host = gf.components.rectangle(
        size=(host_x_um, host_y_um), layer=layer, centered=True
    )
    cutters = gf.Component()
    for sign in (-1.0, 1.0):
        notch = cutters << gf.components.circle(
            radius=8.0, layer=layer
        )
        notch.move((sign * pitch_um / 2, host_y_um / 2))
    result = c << gf.boolean(
        A=host, B=cutters, operation="not", layer=layer
    )
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
