import json
from pathlib import Path

import gdsfactory as gf

lobe_dx_um = 18.36
lobe_dy_um = 10.0
layer = (1, 0)


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    core = gf.components.ellipse(
        radii=(23.0, 13.0), layer=layer
    )
    lobes = gf.Component()
    upper = lobes << gf.components.circle(radius=10.0, layer=layer)
    upper.move((lobe_dx_um, lobe_dy_um))
    lower = lobes << gf.components.circle(radius=8.0, layer=layer)
    lower.move((-lobe_dx_um, -lobe_dy_um))
    result = c << gf.boolean(
        A=core, B=lobes, operation="or", layer=layer
    )
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
