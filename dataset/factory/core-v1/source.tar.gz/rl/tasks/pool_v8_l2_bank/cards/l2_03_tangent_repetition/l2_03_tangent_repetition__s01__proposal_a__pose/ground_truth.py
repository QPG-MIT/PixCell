import json
from pathlib import Path

import gdsfactory as gf

count = 6
radius_um = 6.0
layer = (1, 0)
pose_rotation_deg = 90.0


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    pose_scene = gf.Component()
    for index in range(count):
        disk = pose_scene << gf.components.circle(radius=radius_um, layer=layer)
        disk.move((index * 2 * radius_um, 0))
    pose_ref = c << pose_scene
    pose_ref.rotate(pose_rotation_deg)
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
