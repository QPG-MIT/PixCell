import json
from pathlib import Path

import gdsfactory as gf

width_um = 5.4
lead_um = 27.0
radius_um = 13.0
layer = (1, 0)
pose_rotation_deg = 90.0


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    pose_scene = gf.Component()
    xs = gf.cross_section.cross_section(width=width_um, layer=layer)
    path = gf.Path()
    path.append(gf.path.straight(length=18.0))
    path.append(gf.path.arc(radius=radius_um, angle=90.0))
    path.append(gf.path.straight(length=18.0))
    trace = pose_scene << gf.path.extrude(p=path, cross_section=xs)
    left = pose_scene << gf.components.straight(length=lead_um, cross_section=xs)
    left.connect("o2", trace.ports["o1"])
    right = pose_scene << gf.components.straight(length=lead_um, cross_section=xs)
    right.connect("o1", trace.ports["o2"])
    pose_scene.add_port("o1", port=left.ports["o1"])
    pose_scene.add_port("o2", port=right.ports["o2"])
    pose_ref = c << pose_scene
    pose_ref.rotate(pose_rotation_deg)
    c.add_port("o1", port=pose_ref.ports["o1"])
    c.add_port("o2", port=pose_ref.ports["o2"])
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
