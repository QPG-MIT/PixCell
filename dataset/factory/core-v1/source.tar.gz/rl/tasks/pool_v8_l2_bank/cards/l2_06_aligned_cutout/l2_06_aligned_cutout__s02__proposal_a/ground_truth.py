import json
from pathlib import Path

import gdsfactory as gf

host_width_um = 58.0
host_height_um = 31.0
notch_radius_um = 11.0
layer = (1, 0)


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    host = gf.components.rectangle(
        size=(host_width_um, host_height_um),
        layer=layer,
        centered=True,
    )
    cutter_parent = gf.Component()
    cutter = cutter_parent << gf.components.circle(
        radius=notch_radius_um, layer=layer
    )
    cutter.move((host_width_um / 2, 0))
    result = c << gf.boolean(
        A=host,
        B=cutter_parent,
        operation="not",
        layer=layer,
    )
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
