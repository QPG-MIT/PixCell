import json
from pathlib import Path

import gdsfactory as gf

count = 5
side_um = 8.0
pitch_um = 12.7512
layer = (1, 0)


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    for index in range(count):
        cell = c << gf.components.regular_polygon(
            sides=6, side_length=side_um, layer=layer
        )
        cell.rotate(30)
        cell.move((index * pitch_um, 0))
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
