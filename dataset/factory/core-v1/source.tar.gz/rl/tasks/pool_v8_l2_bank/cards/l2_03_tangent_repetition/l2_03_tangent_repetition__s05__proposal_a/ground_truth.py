import json
from pathlib import Path

import gdsfactory as gf

count = 8
hub_radius_um = 13.0
bar_length_um = 19.0
layer = (1, 0)


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    import math
    hub = c << gf.components.circle(
        radius=hub_radius_um, layer=layer
    )
    orbit_um = hub_radius_um + bar_length_um / 2
    for index in range(count):
        angle_deg = index * 360.0 / count
        angle_rad = math.radians(angle_deg)
        bar = c << gf.components.rectangle(
            size=(bar_length_um, 5.0), layer=layer, centered=True
        )
        bar.rotate(angle_deg)
        bar.move((
            orbit_um * math.cos(angle_rad),
            orbit_um * math.sin(angle_rad),
        ))
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
