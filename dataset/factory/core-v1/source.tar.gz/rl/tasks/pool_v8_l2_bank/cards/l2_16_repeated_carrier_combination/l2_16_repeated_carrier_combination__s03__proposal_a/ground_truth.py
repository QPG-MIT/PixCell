import json
from pathlib import Path

import gdsfactory as gf

count = 10
pitch_um = 10.0
layer = (1, 0)


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    host = gf.components.rectangle(
        size=(105.0, 8.0), layer=layer, centered=True
    )
    fins = gf.Component()
    for index in range(count):
        fin = fins << gf.components.triangle(
            x=9.0, y=18.0, layer=layer
        )
        parity = index % 2
        fin.rotate(180.0 * parity)
        y_um = 4.0 * (1.0 - 2.0 * parity)
        fin.move((
            (index - (count - 1) / 2) * pitch_um,
            y_um,
        ))
    result = c << gf.boolean(
        A=host, B=fins, operation="or", layer=layer
    )
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
