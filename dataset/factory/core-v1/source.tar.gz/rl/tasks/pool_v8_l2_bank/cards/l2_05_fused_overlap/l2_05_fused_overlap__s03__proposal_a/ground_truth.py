import json
from pathlib import Path

import gdsfactory as gf

offset_um = 10.0
layer = (1, 0)


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    polygon = gf.components.regular_polygon(
        sides=7, side_length=12.0, layer=layer
    )
    triangle_parent = gf.Component()
    triangle = triangle_parent << gf.components.triangle(
        x=31.0, y=26.0, layer=layer
    )
    triangle.move((offset_um, -13.0))
    result = c << gf.boolean(
        A=polygon, B=triangle_parent, operation="or", layer=layer
    )
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
