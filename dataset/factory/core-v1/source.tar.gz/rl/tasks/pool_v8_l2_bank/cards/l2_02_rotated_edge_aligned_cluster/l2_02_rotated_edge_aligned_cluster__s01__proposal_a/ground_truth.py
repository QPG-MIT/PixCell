import json
from pathlib import Path

import gdsfactory as gf

angle_a_deg = -32.0
angle_b_deg = 22.0
baseline_y_um = 0.0
layer = (1, 0)


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    first = c << gf.components.rectangle(
        size=(31.0, 9.0), layer=layer, centered=True
    )
    first.rotate(angle_a_deg)
    first.movey(baseline_y_um - first.ymin)
    first.movex(-38.0 - first.xmax)
    second = c << gf.components.rectangle(
        size=(24.0, 10.0), layer=layer, centered=True
    )
    second.rotate(angle_b_deg)
    second.movey(baseline_y_um - second.ymin)
    second.movex(-second.xmin)
    third = c << gf.components.rectangle(
        size=(28.0, 8.0), layer=layer, centered=True
    )
    third.rotate(58)
    third.movey(baseline_y_um - third.ymin)
    third.movex(38.0 - third.xmin)
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
