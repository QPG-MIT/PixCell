import json
from pathlib import Path

import gdsfactory as gf

rows = 4
columns = 4
layer = (1, 0)


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    outer = gf.components.circle(radius=6.0, layer=layer)
    inner = gf.components.circle(radius=2.8, layer=layer)
    unit = gf.boolean(A=outer, B=inner, operation="not", layer=layer)
    ref = c.add_ref(
        unit, rows=rows, columns=columns,
        row_pitch=16.0, column_pitch=17.0
    )
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
