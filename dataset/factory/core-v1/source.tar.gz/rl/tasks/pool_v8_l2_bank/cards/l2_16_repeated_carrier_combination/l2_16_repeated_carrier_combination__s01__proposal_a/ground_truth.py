import json
from pathlib import Path

import gdsfactory as gf

count = 8
pitch_um = 11.0
layer = (1, 0)


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    spine = gf.components.rectangle(
        size=(86.0, 8.0), layer=layer, centered=True
    )
    teeth = gf.Component()
    for index in range(count):
        tooth = teeth << gf.components.rectangle(
            size=(6.0, 23.0), layer=layer, centered=True
        )
        tooth.move(((index - (count - 1) / 2) * pitch_um, 11.0))
    result = c << gf.boolean(
        A=spine, B=teeth, operation="or", layer=layer
    )
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
