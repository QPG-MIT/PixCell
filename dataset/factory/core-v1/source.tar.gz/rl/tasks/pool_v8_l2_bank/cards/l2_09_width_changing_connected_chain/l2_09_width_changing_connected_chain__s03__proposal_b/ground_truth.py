import json
from pathlib import Path

import gdsfactory as gf

narrow_um = 4.86
wide_um = 14.0
layer = (1, 0)


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    narrow_xs = gf.cross_section.cross_section(width=narrow_um, layer=layer)
    wide_xs = gf.cross_section.cross_section(width=wide_um, layer=layer)
    left = c << gf.components.straight(
        length=21.0, cross_section=narrow_xs
    )
    offset = c << gf.components.bend_s(
        size=(38.0, 20.0), cross_section=narrow_xs
    )
    offset.connect("o1", left.ports["o2"])
    wide_a = c << gf.components.straight(
        length=25.0, cross_section=wide_xs
    )
    wide_a.connect(
        "o1", offset.ports["o2"], allow_width_mismatch=True
    )
    right = c << gf.components.straight(
        length=18.0, cross_section=wide_xs
    )
    right.connect("o1", wide_a.ports["o2"])
    c.add_port("o1", port=left.ports["o1"])
    c.add_port("o2", port=right.ports["o2"])
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
