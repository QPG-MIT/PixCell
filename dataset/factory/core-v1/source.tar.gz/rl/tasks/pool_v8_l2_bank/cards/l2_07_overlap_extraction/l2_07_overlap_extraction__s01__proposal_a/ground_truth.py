import json
from pathlib import Path

import gdsfactory as gf

ring_radius_um = 19.0
ring_width_um = 6.0
layer = (1, 0)


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    ring = gf.components.ring(
        radius=ring_radius_um, width=ring_width_um, layer=layer
    )
    cross = gf.components.cross(
        length=48.0, width=11.0, layer=layer
    )
    result = c << gf.boolean(
        A=ring, B=cross, operation="and", layer=layer
    )
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
