import json
from pathlib import Path

import gdsfactory as gf

radius_um = 18.0
separation_um = 20.0
layer = (1, 0)


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    left_parent = gf.Component()
    left = left_parent << gf.components.circle(
        radius=radius_um, layer=layer
    )
    left.movex(-separation_um / 2)
    right_parent = gf.Component()
    right = right_parent << gf.components.circle(
        radius=radius_um, layer=layer
    )
    right.movex(separation_um / 2)
    result = c << gf.boolean(
        A=left_parent, B=right_parent, operation="and", layer=layer
    )
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
