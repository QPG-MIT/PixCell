import json
from pathlib import Path

import gdsfactory as gf

count = 9
host_length_um = 116.0
host_height_um = 9.2
tab_radius_um = 7.0
pitch_um = 13.0
layer = (1, 0)


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    host = gf.components.rectangle(
        size=(host_length_um, host_height_um),
        layer=layer,
        centered=True,
    )
    tabs = gf.Component()
    for index in range(count):
        side = 1.0 if index % 2 == 0 else -1.0
        tab = tabs << gf.components.circle(
            radius=tab_radius_um, layer=layer
        )
        tab.move((
            (index - (count - 1) / 2) * pitch_um,
            side * host_height_um / 2,
        ))
    result = c << gf.boolean(
        A=host, B=tabs, operation="or", layer=layer
    )
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
