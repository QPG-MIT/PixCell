import json
from pathlib import Path

import gdsfactory as gf

bar_length_um = 42.0
cap_radius_um = 11.0
layer = (1, 0)


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    bar = gf.components.rectangle(
        size=(bar_length_um, 16.0), layer=layer, centered=True
    )
    caps = gf.Component()
    left = caps << gf.components.circle(
        radius=cap_radius_um, layer=layer
    )
    left.movex(-bar_length_um / 2)
    right = caps << gf.components.circle(
        radius=cap_radius_um, layer=layer
    )
    right.movex(bar_length_um / 2)
    result = c << gf.boolean(
        A=bar, B=caps, operation="or", layer=layer
    )
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
