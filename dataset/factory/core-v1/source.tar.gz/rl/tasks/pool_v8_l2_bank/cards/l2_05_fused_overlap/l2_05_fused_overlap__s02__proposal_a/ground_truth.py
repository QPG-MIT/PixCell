import json
from pathlib import Path

import gdsfactory as gf

angle_deg = 28.0
layer = (1, 0)


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    cross_parent = gf.Component()
    cross = cross_parent << gf.components.cross(
        length=54.0, width=10.0, layer=layer
    )
    cross.rotate(angle_deg)
    ellipse = gf.components.ellipse(radii=(19.0, 12.0), layer=layer)
    result = c << gf.boolean(
        A=cross_parent, B=ellipse, operation="or", layer=layer
    )
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
