import json
from pathlib import Path

import gdsfactory as gf

top_y_um = 19.44
layer = (1, 0)


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    left = c << gf.components.L(
        width=6.0, size=(22.0, 28.0), layer=layer
    )
    left.rotate(90)
    left.movey(top_y_um - left.ymax)
    left.movex(-36.0 - left.xmax)
    middle = c << gf.components.ellipse(
        radii=(12.0, 7.0), layer=layer
    )
    middle.rotate(28)
    middle.movey(top_y_um - middle.ymax)
    middle.movex(-middle.xmin)
    right = c << gf.components.regular_polygon(
        sides=6, side_length=10.0, layer=layer
    )
    right.rotate(30)
    right.movey(top_y_um - right.ymax)
    right.movex(36.0 - right.xmin)
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
