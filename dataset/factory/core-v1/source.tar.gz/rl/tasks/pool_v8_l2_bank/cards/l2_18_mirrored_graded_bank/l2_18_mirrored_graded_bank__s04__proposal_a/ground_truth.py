import json
from pathlib import Path

import gdsfactory as gf

count = 7
pitch_um = 17.0
gap_um = 12.0
taper_length_um = 11.0
narrow_width_um = 3.0
wide_base_um = 6.0
wide_step_um = 1.4
layer = (1, 0)


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    bank = gf.Component()
    for index in range(count):
        wide_um = wide_base_um + index * wide_step_um
        item = bank << gf.components.taper(
            length=taper_length_um,
            width1=narrow_width_um,
            width2=wide_um,
            layer=layer,
            with_bbox=False,
        )
        item.movex(index * pitch_um)
        item.movey(wide_um / 2)
    max_width_um = wide_base_um + (count - 1) * wide_step_um
    upper = c << bank
    upper.movey(gap_um / 2)
    lower = c << bank
    lower.mirror_y()
    lower.movey(-gap_um / 2)
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
