import json
from pathlib import Path

import gdsfactory as gf

narrow_um = 4.0
middle_um = 8.64
wide_um = 14.0
layer = (1, 0)


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    widths_um = (wide_um, narrow_um, middle_um, narrow_um, wide_um)
    previous = None
    first = None
    for index, stage_width_um in enumerate(widths_um):
        xs = gf.cross_section.cross_section(
            width=stage_width_um, layer=layer
        )
        stage = c << gf.components.straight(
            length=18.0 + 3.0 * (index % 2), cross_section=xs
        )
        if previous is not None:
            stage.connect(
                "o1",
                previous.ports["o2"],
                allow_width_mismatch=True,
            )
        else:
            first = stage
        previous = stage
    c.add_port("o1", port=first.ports["o1"])
    c.add_port("o2", port=previous.ports["o2"])
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
