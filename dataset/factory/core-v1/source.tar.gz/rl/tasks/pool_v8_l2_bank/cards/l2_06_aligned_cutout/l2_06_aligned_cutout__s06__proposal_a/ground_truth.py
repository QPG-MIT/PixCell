import json
from pathlib import Path

import gdsfactory as gf

host_x_um = 60.0
host_y_um = 38.0
angle_deg = 36.0
layer = (1, 0)


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    host = gf.components.rectangle(
        size=(host_x_um, host_y_um), layer=layer, centered=True
    )
    cutter_parent = gf.Component()
    cutter = cutter_parent << gf.components.rectangle(
        size=(72.0, 7.0), layer=layer, centered=True
    )
    cutter.rotate(angle_deg)
    cutter.move((
        -(cutter.xmin + cutter.xmax) / 2,
        -(cutter.ymin + cutter.ymax) / 2,
    ))
    result = c << gf.boolean(
        A=host, B=cutter_parent, operation="not", layer=layer
    )
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
