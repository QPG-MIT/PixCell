import json
from pathlib import Path

import gdsfactory as gf

host_x_um = 53.36
host_y_um = 34.0
tab_um = 12.0
layer = (1, 0)


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    host = gf.components.rectangle(
        size=(host_x_um, host_y_um), layer=layer, centered=True
    )
    tab_parent = gf.Component()
    tab = tab_parent << gf.components.rectangle(
        size=(tab_um, 18.0), layer=layer, centered=True
    )
    tab.movex(host_x_um / 2)
    fused = gf.boolean(
        A=host, B=tab_parent, operation="or", layer=layer
    )
    window_parent = gf.Component()
    window = window_parent << gf.components.rectangle(
        size=(34.0, 17.0), layer=layer, centered=True
    )
    window.movex(-5.0)
    result = c << gf.boolean(
        A=fused, B=window_parent, operation="not", layer=layer
    )
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
