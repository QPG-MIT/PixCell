import json
from pathlib import Path

import gdsfactory as gf

size_x_um = 28.0
size_y_um = 35.0
width_um = 7.0
gap_um = 9.0
layer = (1, 0)


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    lower = c << gf.components.L(
        width=width_um, size=(size_x_um, size_y_um), layer=layer
    )
    lower.move((-size_x_um / 2, -gap_um / 2 - size_y_um))
    upper = c << gf.components.L(
        width=width_um, size=(size_x_um, size_y_um), layer=layer
    )
    upper.mirror_x()
    upper.move((-size_x_um / 2, gap_um / 2 + size_y_um))
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
