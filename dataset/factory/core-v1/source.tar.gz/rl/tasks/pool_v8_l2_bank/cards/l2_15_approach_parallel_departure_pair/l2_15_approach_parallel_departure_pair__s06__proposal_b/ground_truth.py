import json
from pathlib import Path

import gdsfactory as gf

width_um = 5.0
inner_radius_um = 31.28
radial_pitch_um = 13.0
sweep_deg = 105.0
layer = (1, 0)


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    xs = gf.cross_section.cross_section(width=width_um, layer=layer)
    inner_path = gf.path.arc(
        radius=inner_radius_um, angle=sweep_deg
    )
    outer_path = gf.path.arc(
        radius=inner_radius_um + radial_pitch_um, angle=sweep_deg
    )
    inner = c << gf.path.extrude(inner_path, cross_section=xs)
    outer = c << gf.path.extrude(outer_path, cross_section=xs)
    outer.movey(-radial_pitch_um)
    inner_lead = c << gf.components.straight(
        length=15.0, cross_section=xs
    )
    inner_lead.connect("o2", inner.ports["o1"])
    outer_lead = c << gf.components.straight(
        length=15.0, cross_section=xs
    )
    outer_lead.connect("o2", outer.ports["o1"])
    c.add_port("o1", port=inner_lead.ports["o1"])
    c.add_port("o2", port=outer_lead.ports["o1"])
    c.add_port("o3", port=inner.ports["o2"])
    c.add_port("o4", port=outer.ports["o2"])
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
