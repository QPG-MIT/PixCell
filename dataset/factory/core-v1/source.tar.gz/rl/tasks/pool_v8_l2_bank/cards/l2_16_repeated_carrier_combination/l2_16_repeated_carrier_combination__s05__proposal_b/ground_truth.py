import json
from pathlib import Path

import gdsfactory as gf

columns = 6
host_length_um = 104.0
host_height_um = 31.0
slot_radius_x_um = 4.5
slot_radius_y_um = 3.5
pitch_x_um = 18.36
pitch_y_um = 14.0
layer = (1, 0)


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    host = gf.components.rectangle(
        size=(host_length_um, host_height_um),
        layer=layer,
        centered=True,
    )
    cutters = gf.Component()
    for column in range(columns):
        for row_sign in (-1.0, 1.0):
            slot = cutters << gf.components.ellipse(
                radii=(slot_radius_x_um, slot_radius_y_um),
                layer=layer,
            )
            slot.move((
                (column - (columns - 1) / 2) * pitch_x_um,
                row_sign * pitch_y_um / 2,
            ))
    result = c << gf.boolean(
        A=host, B=cutters, operation="not", layer=layer
    )
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
