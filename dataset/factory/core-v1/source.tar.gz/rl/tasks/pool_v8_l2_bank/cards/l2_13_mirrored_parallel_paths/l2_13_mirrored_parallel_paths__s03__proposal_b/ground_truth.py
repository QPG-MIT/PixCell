import json
from pathlib import Path

import gdsfactory as gf

width_um = 4.86
gap_um = 30.0
layer = (1, 0)


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    path = gf.Path()
    path.append(gf.path.straight(length=15.0))
    path.append(gf.path.arc(radius=10.0, angle=72.0))
    path.append(gf.path.straight(length=19.0))
    path.append(gf.path.arc(radius=10.0, angle=-118.0))
    path.append(gf.path.straight(length=22.0))
    path.append(gf.path.arc(radius=10.0, angle=46.0))
    path.append(gf.path.straight(length=15.0))
    xs = gf.cross_section.cross_section(width=width_um, layer=layer)
    first = c << gf.path.extrude(path, cross_section=xs)
    first.move((0, gap_um / 2))
    second = c << gf.path.extrude(path, cross_section=xs)
    second.mirror_y()
    second.move((0, -gap_um / 2))
    c.add_port("o1", port=first.ports["o1"])
    c.add_port("o2", port=first.ports["o2"])
    c.add_port("o3", port=second.ports["o1"])
    c.add_port("o4", port=second.ports["o2"])
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
