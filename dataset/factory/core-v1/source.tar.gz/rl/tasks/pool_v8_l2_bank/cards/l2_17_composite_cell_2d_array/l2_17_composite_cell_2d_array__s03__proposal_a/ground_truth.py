import json
from pathlib import Path

import gdsfactory as gf

rows = 2
columns = 5
layer = (1, 0)


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    disk = gf.components.circle(radius=7.0, layer=layer)
    cutter_parent = gf.Component()
    cutter = cutter_parent << gf.components.rectangle(
        size=(8.0, 5.0), layer=layer, centered=True
    )
    cutter.move((6.0, 0))
    unit = gf.boolean(
        A=disk, B=cutter_parent, operation="not", layer=layer
    )
    ref = c.add_ref(
        unit, rows=rows, columns=columns,
        row_pitch=19.0, column_pitch=18.0
    )
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
