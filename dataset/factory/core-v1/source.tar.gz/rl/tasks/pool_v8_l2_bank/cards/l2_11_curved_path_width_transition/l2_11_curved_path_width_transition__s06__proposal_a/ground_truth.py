import json
from pathlib import Path

import gdsfactory as gf

wide_um = 14.0
narrow_um = 4.0
radius_um = 13.0
layer = (1, 0)


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    wide_xs = gf.cross_section.cross_section(width=wide_um, layer=layer)
    narrow_xs = gf.cross_section.cross_section(width=narrow_um, layer=layer)
    path_a = gf.Path()
    path_a.append(gf.path.straight(length=18.0))
    path_a.append(gf.path.arc(radius=radius_um, angle=58.0))
    contract = gf.path.transition(
        cross_section1=wide_xs,
        cross_section2=narrow_xs,
        width_type="sine",
    )
    first = c << gf.path.extrude_transition(
        p=path_a, transition=contract
    )
    path_b = gf.Path()
    path_b.append(gf.path.arc(radius=radius_um, angle=-58.0))
    path_b.append(gf.path.straight(length=18.0))
    expand = gf.path.transition(
        cross_section1=narrow_xs,
        cross_section2=wide_xs,
        width_type="sine",
    )
    second = c << gf.path.extrude_transition(
        p=path_b, transition=expand
    )
    second.connect("o1", first.ports["o2"])
    c.add_port("o1", port=first.ports["o1"])
    c.add_port("o2", port=second.ports["o2"])
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
