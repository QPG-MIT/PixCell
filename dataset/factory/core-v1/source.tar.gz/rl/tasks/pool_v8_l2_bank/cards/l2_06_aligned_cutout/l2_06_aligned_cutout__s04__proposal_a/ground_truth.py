import json
from pathlib import Path

import gdsfactory as gf

host_x_um = 58.0
host_y_um = 38.0
layer = (1, 0)


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    host = gf.components.rectangle(
        size=(host_x_um, host_y_um), layer=layer, centered=True
    )
    cutter_parent = gf.Component()
    cutter = cutter_parent << gf.components.triangle(
        x=24.0, y=20.0, layer=layer
    )
    cutter.move((
        -(cutter.xmin + cutter.xmax) / 2,
        -(cutter.ymin + cutter.ymax) / 2,
    ))
    result = c << gf.boolean(
        A=host, B=cutter_parent, operation="not", layer=layer
    )
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
