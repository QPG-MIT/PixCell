import json
from pathlib import Path

import gdsfactory as gf

count = 6
pitch_um = 30.0
gap_um = 13.0
length_base_um = 11.0
length_step_um = 2.8
width_base_um = 5.4
width_step_um = 0.35
layer = (1, 0)


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    bank = gf.Component()
    for index in range(count):
        length_um = length_base_um + index * length_step_um
        width_um = width_base_um - index * width_step_um
        item = bank << gf.components.cross(
            length=length_um, width=width_um, layer=layer
        )
        item.movex(index * pitch_um)
        item.movey(length_um / 2)
    max_length_um = length_base_um + (count - 1) * length_step_um
    upper = c << bank
    upper.movey(gap_um / 2)
    lower = c << bank
    lower.mirror_y()
    lower.movey(-gap_um / 2)
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
