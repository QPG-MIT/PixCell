import json
from pathlib import Path

import gdsfactory as gf

narrow_um = 4.0
wide_um = 11.96
layer = (1, 0)


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    smooth_segment = gf.path.smooth(
        points=[
            (0, 0), (18, 0), (36, 21),
            (58, 21), (76, 0), (96, 0)
        ],
        radius=7.0
    )
    path = gf.Path()
    path.append(smooth_segment)
    path.append(gf.path.straight(length=14.0))
    narrow_xs = gf.cross_section.cross_section(
        width=narrow_um, layer=layer
    )
    wide_xs = gf.cross_section.cross_section(
        width=wide_um, layer=layer
    )
    profile = gf.path.transition(
        cross_section1=narrow_xs,
        cross_section2=wide_xs,
        width_type="linear",
    )
    trace = c << gf.path.extrude_transition(
        p=path, transition=profile
    )
    c.add_port("o1", port=trace.ports["o1"])
    c.add_port("o2", port=trace.ports["o2"])
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
