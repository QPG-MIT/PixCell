import json
from pathlib import Path

import gdsfactory as gf

width_um = 5.0
outer_pitch_um = 34.0
inner_pitch_um = 12.0
layer = (1, 0)


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    xs = gf.cross_section.cross_section(width=width_um, layer=layer)
    shift_um = (outer_pitch_um - inner_pitch_um) / 2
    rail_cell = gf.Component()
    approach = rail_cell << gf.components.bend_s(
        size=(32.0, -shift_um), cross_section=xs
    )
    run = rail_cell << gf.components.straight(
        length=58.0, cross_section=xs
    )
    run.connect("o1", approach.ports["o2"])
    rail_cell.add_port("o1", port=approach.ports["o1"])
    rail_cell.add_port("o2", port=run.ports["o2"])
    upper = c << rail_cell
    upper.movey(outer_pitch_um / 2)
    lower = c << rail_cell
    lower.mirror_y()
    lower.movey(-outer_pitch_um / 2)
    c.add_port("o1", port=upper.ports["o1"])
    c.add_port("o2", port=lower.ports["o1"])
    c.add_port("o3", port=upper.ports["o2"])
    c.add_port("o4", port=lower.ports["o2"])
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
