import json
from pathlib import Path

import gdsfactory as gf

width_um = 4.5
outer_pitch_um = 32.0
inner_pitch_um = 10.0
layer = (1, 0)


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    xs = gf.cross_section.cross_section(width=width_um, layer=layer)
    shift_um = (outer_pitch_um - inner_pitch_um) / 2
    rail_cell = gf.Component()
    approach = rail_cell << gf.components.bend_s(
        size=(27.0, -shift_um), cross_section=xs
    )
    run = rail_cell << gf.components.straight(
        length=40.0, cross_section=xs
    )
    run.connect("o1", approach.ports["o2"])
    depart = rail_cell << gf.components.bend_s(
        size=(27.0, shift_um), cross_section=xs
    )
    depart.connect("o1", run.ports["o2"])
    rail_cell.add_port("o1", port=approach.ports["o1"])
    rail_cell.add_port("o2", port=depart.ports["o2"])
    upper = c << rail_cell
    upper.movey(outer_pitch_um / 2)
    lower = c << rail_cell
    lower.mirror_y()
    lower.movey(-outer_pitch_um / 2)
    upper_tail = c << gf.components.straight(
        length=13.0, cross_section=xs
    )
    upper_tail.connect("o1", upper.ports["o2"])
    lower_tail = c << gf.components.straight(
        length=31.0, cross_section=xs
    )
    lower_tail.connect("o1", lower.ports["o2"])
    c.add_port("o1", port=upper.ports["o1"])
    c.add_port("o2", port=lower.ports["o1"])
    c.add_port("o3", port=upper_tail.ports["o2"])
    c.add_port("o4", port=lower_tail.ports["o2"])
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
