import json
from pathlib import Path

import gdsfactory as gf

offset_um = 16.2
layer = (1, 0)
pose_rotation_deg = 90.0


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    pose_scene = gf.Component()
    disk_parent = gf.Component()
    disk = disk_parent << gf.components.circle(radius=15.0, layer=layer)
    disk.move((-offset_um, 0))
    bar_parent = gf.Component()
    bar = bar_parent << gf.components.rectangle(
        size=(42.0, 13.0), layer=layer, centered=True
    )
    bar.move((offset_um / 2, 0))
    result = pose_scene << gf.boolean(
        A=disk_parent, B=bar_parent, operation="or", layer=layer
    )
    pose_ref = c << pose_scene
    pose_ref.rotate(pose_rotation_deg)
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
