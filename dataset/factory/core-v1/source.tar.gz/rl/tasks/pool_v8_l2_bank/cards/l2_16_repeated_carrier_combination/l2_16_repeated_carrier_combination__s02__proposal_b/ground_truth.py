import json
from pathlib import Path

import gdsfactory as gf

count = 7
pitch_um = 11.04
layer = (1, 0)


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    host = gf.components.rectangle(
        size=(92.0, 24.0), layer=layer, centered=True
    )
    cutters = gf.Component()
    for index in range(count):
        hole = cutters << gf.components.circle(radius=4.0, layer=layer)
        hole.move(((index - (count - 1) / 2) * pitch_um, 0))
    result = c << gf.boolean(
        A=host, B=cutters, operation="not", layer=layer
    )
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
