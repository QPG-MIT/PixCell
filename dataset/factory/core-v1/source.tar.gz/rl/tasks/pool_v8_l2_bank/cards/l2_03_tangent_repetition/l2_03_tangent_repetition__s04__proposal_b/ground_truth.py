import json
from pathlib import Path

import gdsfactory as gf

pair_count = 3
radius_um = 6.0
side_um = 11.04
layer = (1, 0)


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    previous = c << gf.components.circle(
        radius=radius_um, layer=layer
    )
    for pair_index in range(pair_count):
        square = c << gf.components.rectangle(
            size=(side_um, side_um), layer=layer, centered=True
        )
        square.movex(previous.xmax - square.xmin)
        disk = c << gf.components.circle(
            radius=radius_um, layer=layer
        )
        disk.movex(square.xmax - disk.xmin)
        previous = disk
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
