import json
from pathlib import Path

import gdsfactory as gf

width_um = 5.0
gap_um = 12.0
layer = (1, 0)
pose_rotation_deg = 90.0


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    pose_scene = gf.Component()
    path = gf.Path()
    path.append(gf.path.straight(length=18.0))
    path.append(gf.path.arc(radius=12.0, angle=58.0))
    path.append(gf.path.straight(length=24.0))
    path.append(gf.path.arc(radius=12.0, angle=-58.0))
    path.append(gf.path.straight(length=18.0))
    xs = gf.cross_section.cross_section(width=width_um, layer=layer)
    upper = pose_scene << gf.path.extrude(path, cross_section=xs)
    upper.move((0, gap_um / 2))
    lower = pose_scene << gf.path.extrude(path, cross_section=xs)
    lower.mirror_y()
    lower.move((0, -gap_um / 2))
    pose_scene.add_port("o1", port=upper.ports["o1"])
    pose_scene.add_port("o2", port=upper.ports["o2"])
    pose_scene.add_port("o3", port=lower.ports["o1"])
    pose_scene.add_port("o4", port=lower.ports["o2"])
    pose_ref = c << pose_scene
    pose_ref.rotate(pose_rotation_deg)
    c.add_port("o1", port=pose_ref.ports["o1"])
    c.add_port("o2", port=pose_ref.ports["o2"])
    c.add_port("o3", port=pose_ref.ports["o3"])
    c.add_port("o4", port=pose_ref.ports["o4"])
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
