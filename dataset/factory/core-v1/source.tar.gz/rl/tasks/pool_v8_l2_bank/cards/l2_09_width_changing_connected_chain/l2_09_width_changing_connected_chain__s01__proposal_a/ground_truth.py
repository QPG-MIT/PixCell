import json
from pathlib import Path

import gdsfactory as gf

narrow_um = 4.0
wide_um = 14.0
lead_um = 23.0
layer = (1, 0)


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    narrow_xs = gf.cross_section.cross_section(width=narrow_um, layer=layer)
    wide_xs = gf.cross_section.cross_section(width=wide_um, layer=layer)
    left = c << gf.components.straight(length=lead_um, cross_section=narrow_xs)
    wide_a = c << gf.components.straight(
        length=24.0, cross_section=wide_xs
    )
    wide_a.connect(
        "o1", left.ports["o2"], allow_width_mismatch=True
    )
    wide_b = c << gf.components.straight(
        length=18.0, cross_section=wide_xs
    )
    wide_b.connect("o1", wide_a.ports["o2"])
    right = c << gf.components.straight(
        length=lead_um, cross_section=narrow_xs
    )
    right.connect(
        "o1", wide_b.ports["o2"], allow_width_mismatch=True
    )
    c.add_port("o1", port=left.ports["o1"])
    c.add_port("o2", port=right.ports["o2"])
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
