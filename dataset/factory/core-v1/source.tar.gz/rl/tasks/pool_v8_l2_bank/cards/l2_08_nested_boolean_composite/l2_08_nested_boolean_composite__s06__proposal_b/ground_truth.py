import json
from pathlib import Path

import gdsfactory as gf

tail_offset_um = 20.0
bite_offset_um = 38.64
layer = (1, 0)


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    core = gf.components.ellipse(
        radii=(22.0, 15.0), layer=layer
    )
    tail_parent = gf.Component()
    tail = tail_parent << gf.components.rectangle(
        size=(34.0, 13.0), layer=layer, centered=True
    )
    tail.movex(tail_offset_um)
    fused = gf.boolean(
        A=core, B=tail_parent, operation="or", layer=layer
    )
    cutter_parent = gf.Component()
    bite = cutter_parent << gf.components.triangle(
        x=-22.0, y=-22.0, layer=layer
    )
    bite.move((bite_offset_um, 10.0))
    result = c << gf.boolean(
        A=fused, B=cutter_parent, operation="not", layer=layer
    )
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
