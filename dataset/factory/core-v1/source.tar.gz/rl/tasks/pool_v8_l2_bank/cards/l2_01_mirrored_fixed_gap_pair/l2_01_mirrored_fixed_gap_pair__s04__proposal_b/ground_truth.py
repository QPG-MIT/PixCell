import json
from pathlib import Path

import gdsfactory as gf

gap_um = 9.0
tab_length_um = 14.72
layer = (1, 0)


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    unit = gf.Component()
    core = unit << gf.components.ellipse(
        radii=(14.0, 9.0), layer=layer
    )
    tab = unit << gf.components.rectangle(
        size=(tab_length_um, 6.0), layer=layer, centered=True
    )
    tab.movex(13.0)
    left = c << unit
    left.mirror()
    left.movex(-gap_um / 2 - left.xmax)
    right = c << unit
    right.movex(gap_um / 2 - right.xmin)
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
