import json
from pathlib import Path

import gdsfactory as gf

lead_width_um = 4.6
interaction_width_um = 8.0
interaction_gap_um = 6.0
outer_pitch_um = 38.0
window_length_um = 41.04
approach_length_um = 32.0
taper_length_um = 18.0
layer = (1, 0)


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    lead_xs = gf.cross_section.cross_section(
        width=lead_width_um, layer=layer
    )
    interaction_xs = gf.cross_section.cross_section(
        width=interaction_width_um, layer=layer
    )
    inner_pitch_um = interaction_width_um + interaction_gap_um
    shift_um = (outer_pitch_um - inner_pitch_um) / 2
    upper_approach = c << gf.components.bend_s(
        size=(approach_length_um, -shift_um),
        cross_section=lead_xs,
    )
    lower_approach = c << gf.components.bend_s(
        size=(approach_length_um, -shift_um),
        cross_section=lead_xs,
    )
    lower_approach.mirror_y()
    upper_approach.movey(outer_pitch_um / 2)
    lower_approach.movey(-outer_pitch_um / 2)

    upper_taper_in = c << gf.components.taper(
        length=taper_length_um,
        width1=lead_width_um,
        width2=interaction_width_um,
        layer=layer,
        with_bbox=False,
    )
    lower_taper_in = c << gf.components.taper(
        length=taper_length_um,
        width1=lead_width_um,
        width2=interaction_width_um,
        layer=layer,
        with_bbox=False,
    )
    upper_window = c << gf.components.straight(
        length=window_length_um, cross_section=interaction_xs
    )
    lower_window = c << gf.components.straight(
        length=window_length_um, cross_section=interaction_xs
    )
    upper_taper_out = c << gf.components.taper(
        length=taper_length_um,
        width1=interaction_width_um,
        width2=lead_width_um,
        layer=layer,
        with_bbox=False,
    )
    lower_taper_out = c << gf.components.taper(
        length=taper_length_um,
        width1=interaction_width_um,
        width2=lead_width_um,
        layer=layer,
        with_bbox=False,
    )
    upper_depart = c << gf.components.bend_s(
        size=(approach_length_um, shift_um),
        cross_section=lead_xs,
    )
    lower_depart = c << gf.components.bend_s(
        size=(approach_length_um, shift_um),
        cross_section=lead_xs,
    )

    upper_taper_in.connect("o1", upper_approach.ports["o2"])
    lower_taper_in.connect("o1", lower_approach.ports["o2"])
    upper_window.connect("o1", upper_taper_in.ports["o2"])
    lower_window.connect("o1", lower_taper_in.ports["o2"])
    upper_taper_out.connect("o1", upper_window.ports["o2"])
    lower_taper_out.connect("o1", lower_window.ports["o2"])
    upper_depart.connect("o1", upper_taper_out.ports["o2"])
    lower_depart.connect(
        "o1", lower_taper_out.ports["o2"], mirror=True
    )
    c.add_port("o1", port=upper_approach.ports["o1"])
    c.add_port("o2", port=lower_approach.ports["o1"])
    c.add_port("o3", port=upper_depart.ports["o2"])
    c.add_port("o4", port=lower_depart.ports["o2"])
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
