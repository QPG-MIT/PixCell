import json
from pathlib import Path

import gdsfactory as gf

count = 7
host_length_um = 102.0
host_height_um = 11.0
tooth_width_um = 7.0
tooth_base_height_um = 10.0
tooth_height_step_um = 3.2
pitch_um = 14.0
layer = (1, 0)


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    host = gf.components.rectangle(
        size=(host_length_um, host_height_um),
        layer=layer,
        centered=True,
    )
    teeth = gf.Component()
    for index in range(count):
        height_um = tooth_base_height_um + index * tooth_height_step_um
        tooth = teeth << gf.components.rectangle(
            size=(tooth_width_um, height_um),
            layer=layer,
            centered=True,
        )
        tooth.move((
            (index - (count - 1) / 2) * pitch_um,
            host_height_um / 2 + height_um / 2 - 2.0,
        ))
    result = c << gf.boolean(
        A=host, B=teeth, operation="or", layer=layer
    )
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
