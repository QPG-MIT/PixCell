import json
from pathlib import Path

import gdsfactory as gf

width_um = 5.0
radius_small_um = 8.0
radius_large_um = 15.0
gap_um = 38.0
layer = (1, 0)


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    path = gf.Path()
    path.append(gf.path.straight(length=17.0))
    path.append(gf.path.arc(radius=radius_small_um, angle=78.0))
    path.append(gf.path.straight(length=21.0))
    path.append(gf.path.arc(radius=radius_large_um, angle=-128.0))
    path.append(gf.path.straight(length=25.0))
    path.append(gf.path.arc(radius=radius_small_um, angle=50.0))
    path.append(gf.path.straight(length=17.0))
    xs = gf.cross_section.cross_section(width=width_um, layer=layer)
    upper = c << gf.path.extrude(path, cross_section=xs)
    upper.movey(gap_um / 2)
    lower = c << gf.path.extrude(path, cross_section=xs)
    lower.mirror_y()
    lower.movey(-gap_um / 2)
    c.add_port("o1", port=upper.ports["o1"])
    c.add_port("o2", port=upper.ports["o2"])
    c.add_port("o3", port=lower.ports["o1"])
    c.add_port("o4", port=lower.ports["o2"])
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
