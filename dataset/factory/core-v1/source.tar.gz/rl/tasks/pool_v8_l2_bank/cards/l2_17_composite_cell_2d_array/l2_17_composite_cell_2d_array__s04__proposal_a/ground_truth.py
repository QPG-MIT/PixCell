import json
from pathlib import Path

import gdsfactory as gf

rows = 3
columns = 4
cell_x_um = 18.0
cell_y_um = 18.0
cross_length_um = 11.0
cross_width_um = 4.0
row_pitch_um = 24.0
column_pitch_um = 24.0
layer = (1, 0)


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    host = gf.components.rectangle(
        size=(cell_x_um, cell_y_um), layer=layer, centered=True
    )
    cutter = gf.components.cross(
        length=cross_length_um, width=cross_width_um, layer=layer
    )
    unit = gf.boolean(
        A=host, B=cutter, operation="not", layer=layer
    )
    ref = c.add_ref(
        unit,
        rows=rows,
        columns=columns,
        row_pitch=row_pitch_um,
        column_pitch=column_pitch_um,
    )
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
