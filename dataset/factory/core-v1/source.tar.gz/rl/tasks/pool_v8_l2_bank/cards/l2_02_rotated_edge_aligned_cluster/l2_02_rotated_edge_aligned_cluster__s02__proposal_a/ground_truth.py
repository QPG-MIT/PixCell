import json
from pathlib import Path

import gdsfactory as gf

pitch_um = 31.0
baseline_y_um = 0.0
layer = (1, 0)


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    left = c << gf.components.triangle(
        x=19.0, y=25.0, layer=layer
    )
    left.rotate(-18.0)
    left.movey(baseline_y_um - left.ymin)
    left.movex(-pitch_um - left.xmin)
    middle = c << gf.components.triangle(
        x=22.0, y=25.0, layer=layer
    )
    middle.rotate(0.0)
    middle.movey(baseline_y_um - middle.ymin)
    middle.movex(-middle.xmin)
    right = c << gf.components.triangle(
        x=25.0, y=25.0, layer=layer
    )
    right.rotate(24.0)
    right.movey(baseline_y_um - right.ymin)
    right.movex(pitch_um - right.xmin)
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
