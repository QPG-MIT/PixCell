import json
from pathlib import Path

import gdsfactory as gf

length_um = 33.48
narrow_um = 4.0
wide_um = 13.0
gap_um = 8.0
layer = (1, 0)


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    left = c << gf.components.taper(
        length=length_um, width1=narrow_um, width2=wide_um,
        layer=layer, with_bbox=False
    )
    left.move((-length_um - gap_um / 2, 0))
    right = c << gf.components.taper(
        length=length_um, width1=narrow_um, width2=wide_um,
        layer=layer, with_bbox=False
    )
    right.mirror()
    right.move((length_um + gap_um / 2, 0))
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
