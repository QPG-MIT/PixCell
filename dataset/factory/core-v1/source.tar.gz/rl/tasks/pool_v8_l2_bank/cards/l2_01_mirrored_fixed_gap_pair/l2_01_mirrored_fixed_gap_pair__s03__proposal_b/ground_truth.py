import json
from pathlib import Path

import gdsfactory as gf

span_um = 30.0
height_um = 24.0
gap_um = 10.8
layer = (1, 0)


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    first = c << gf.components.triangle(
        x=span_um, y=height_um, layer=layer
    )
    first.rotate(28)
    first.move((-span_um - gap_um / 2, -9.0))
    second = c << gf.components.triangle(
        x=span_um, y=height_um, layer=layer
    )
    second.mirror()
    second.rotate(-28)
    second.move((gap_um / 2, 9.0))
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
