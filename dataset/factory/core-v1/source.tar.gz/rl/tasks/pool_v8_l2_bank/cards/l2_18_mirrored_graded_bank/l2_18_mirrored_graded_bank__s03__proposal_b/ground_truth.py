import json
from pathlib import Path

import gdsfactory as gf

count = 8
pitch_um = 27.0
gap_um = 13.0
layer = (1, 0)


@gf.cell(check_instances=False)
def device():
    c = gf.Component()
    bank = gf.Component()
    for index in range(count):
        side_um = 5.0 + (index % 2) * 4.0 + index * 0.45
        item = bank << gf.components.regular_polygon(
            sides=6, side_length=side_um, layer=layer
        )
        item.movey(-item.ymin)
        item.movex(index * pitch_um)
    upper = c << bank
    upper.movey(gap_um / 2)
    lower = c << bank
    lower.mirror_y()
    lower.movey(-gap_um / 2)
    return c


if __name__ == "__main__":
    component = device()
    component.write_gds("device.gds", with_metadata=False)
